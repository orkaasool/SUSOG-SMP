# ---------------------- Objectives ----------------------

# ID for player
scoreboard objectives add eggid dummy
scoreboard players set .cur_id eggid 0
scoreboard players set .this eggid 0


# HP stuff
scoreboard objectives add LDHealth dummy
scoreboard players set .max LDHealth 400

# ID
scoreboard objectives add LDid dummy

# AI stuff
scoreboard objectives add LDState dummy
scoreboard objectives add LDChoose dummy

scoreboard objectives add LDTimer1 dummy
scoreboard objectives add LDTimer2 dummy
scoreboard objectives add LDTimer3 dummy

# Random Var
scoreboard objectives add LDVar1 dummy
scoreboard players set .ld_total_segment LDVar1 31


# For spear stuff
scoreboard objectives add SoulSpearCooldown dummy
scoreboard objectives add SoulSpearEnergy dummy
scoreboard players set .needed SoulSpearEnergy 25


# ---------------------- Boss Bar ------------------------
# Make the Boss Bar
bossbar add ldragon_bar {"color":"#5E99FF","text":"The Sovereign of Lost Souls, Deathmire"}
bossbar set minecraft:ldragon_bar players @a
# Decorations
bossbar set ldragon_bar name {"color":"#5E99FF","text":"The Sovereign of Lost Souls, Deathmire"}
bossbar set ldragon_bar color blue
bossbar set ldragon_bar style progress


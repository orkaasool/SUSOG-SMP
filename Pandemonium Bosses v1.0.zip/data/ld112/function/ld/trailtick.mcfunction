
scoreboard players operation .this LDid = @s LDid
execute as @e[tag=ldragon] if score @s LDid = .this LDid run tag @s add this


execute unless entity @e[tag=ldmain] run kill @s


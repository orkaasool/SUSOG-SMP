
scoreboard players operation .this LDid = @s LDid
execute as @e[tag=ldragon] if score @s LDid = .this LDid run tag @s add this

# AI
execute if score @s LDState matches 1 run function ld112:ld/states/soar
execute if score @s LDState matches 2 run function ld112:ld/states/charge
execute if score @s LDState matches 3 run function ld112:ld/states/heaven
execute if score @s LDState matches 420 run function ld112:ld/states/dying

# FX
particle minecraft:soul_fire_flame ^0.8 ^1.1 ^-3 0 0 0 0.01 1 force
particle minecraft:soul_fire_flame ^-0.8 ^1.1 ^-3 0 0 0 0.01 1 force


# Damage Player
execute as @e[tag=ldragon,type=item_display,tag=this] at @s run execute positioned ~-0.5 ~-0.5 ~-0.5 as @p[dx=0] run damage @s 23 minecraft:mob_attack by @n[tag=this,tag=ldragon,type=vex]


# HP handler
execute as @e[tag=ldragon,tag=this,type=vex,nbt={HurtTime:10s}] at @s run function ld112:ld/hp/hit_detect
execute as @e[tag=ldragon,tag=this,type=vex,nbt={HurtTime:5s}] at @s run function ld112:ld/hp/seg_hurt
# Update bossbar
execute store result bossbar minecraft:ldragon_bar value run scoreboard players get @s LDHealth

execute if entity @s[tag=dead] unless score @s LDState matches 420 run function ld112:ld/hp/dead


# Trail
tp @e[tag=ldhead,type=vex,tag=this] ~ ~-0.5 ~
execute as @e[tag=ldsegs,tag=this] at @s run function ld112:ld/trail
execute as @e[tag=ldsegs,type=vex,tag=this] at @s run tp @s ~ ~-0.25 ~


execute unless entity @p[distance=..500] run function ld112:ld/despawn


tag @e[tag=this] remove this
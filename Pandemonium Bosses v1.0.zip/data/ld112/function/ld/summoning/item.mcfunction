


execute store result score .blevel LDVar1 run data get block ~ ~-0.5 ~ Levels 1

execute if score .blevel LDVar1 matches 1.. align xz run summon marker ~0.5 ~ ~0.5 {Tags:["ld112","ldsummonmark"]}
execute if score .blevel LDVar1 matches 1.. run particle minecraft:soul_fire_flame ~ ~ ~ 0 0 0 0.1 30 normal
execute if score .blevel LDVar1 matches 1.. run particle minecraft:soul ~ ~ ~ 1 0.5 1 0.01 30 normal
execute if score .blevel LDVar1 matches 1.. run playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 1 1
execute if score .blevel LDVar1 matches 1.. run advancement grant @a only ld112:ld/root
execute if score .blevel LDVar1 matches 1.. run kill @s
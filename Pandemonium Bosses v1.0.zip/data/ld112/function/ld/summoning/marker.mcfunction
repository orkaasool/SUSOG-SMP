

scoreboard players add @s LDTimer1 1


particle minecraft:soul_fire_flame ^ ^ ^1 0 0 0 0.01 1
particle minecraft:soul_fire_flame ^ ^ ^-1 0 0 0 0.01 1
particle minecraft:soul ~ ~ ~ 1 1 1 0.01 1

tp @s ~ ~ ~ ~10 ~
execute if score @s LDTimer1 matches 20..240 run tp @s ~ ~0.1 ~

execute if score @s LDTimer1 matches 80.. run tp @s ~ ~0.15 ~
execute if score @s LDTimer1 matches 80.. run particle minecraft:end_rod ~ ~ ~ 1 0 1 0.01 1

execute if score @s LDTimer1 matches 160.. run tp @s ~ ~0.2 ~
execute if score @s LDTimer1 matches 160.. run particle minecraft:firework ~ ~15 ~ 0.5 15 0.5 0.1 10 normal

execute if score @s LDTimer1 matches 200 run function ld112:ld/summoning/cool_summon
execute if score @s LDTimer1 matches 200 run playsound minecraft:entity.ender_dragon.ambient hostile @a ~ ~ ~ 1 1 1
execute if score @s LDTimer1 matches 200 run playsound minecraft:entity.wither.death hostile @a ~ ~ ~ 1 1 1
execute if score @s LDTimer1 matches 200 run particle minecraft:cloud ~ ~15 ~ 0.5 15 0.5 0.1 100 force
execute if score @s LDTimer1 matches 200 run effect give @a minecraft:blindness 1 1
execute if score @s LDTimer1 matches 200.. run kill @s
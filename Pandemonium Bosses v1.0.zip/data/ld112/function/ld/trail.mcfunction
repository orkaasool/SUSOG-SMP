

execute if entity @s[tag=ldseg1,tag=this] at @e[tag=ldhead,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1

execute if entity @s[tag=ldseg2,tag=this] at @e[tag=ldseg1,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg3,tag=this] at @e[tag=ldseg2,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg4,tag=this] at @e[tag=ldseg3,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg5,tag=this] at @e[tag=ldseg4,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg6,tag=this] at @e[tag=ldseg5,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg7,tag=this] at @e[tag=ldseg6,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg8,tag=this] at @e[tag=ldseg7,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg9,tag=this] at @e[tag=ldseg8,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg10,tag=this] at @e[tag=ldseg9,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg11,tag=this] at @e[tag=ldseg10,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg12,tag=this] at @e[tag=ldseg11,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg13,tag=this] at @e[tag=ldseg12,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg14,tag=this] at @e[tag=ldseg13,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg15,tag=this] at @e[tag=ldseg14,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg16,tag=this] at @e[tag=ldseg15,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg17,tag=this] at @e[tag=ldseg16,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg18,tag=this] at @e[tag=ldseg17,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg19,tag=this] at @e[tag=ldseg18,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg20,tag=this] at @e[tag=ldseg19,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg21,tag=this] at @e[tag=ldseg20,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg22,tag=this] at @e[tag=ldseg21,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg23,tag=this] at @e[tag=ldseg22,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg24,tag=this] at @e[tag=ldseg23,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg25,tag=this] at @e[tag=ldseg24,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg26,tag=this] at @e[tag=ldseg25,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg27,tag=this] at @e[tag=ldseg26,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg28,tag=this] at @e[tag=ldseg27,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg29,tag=this] at @e[tag=ldseg28,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1
execute if entity @s[tag=ldseg30,tag=this] at @e[tag=ldseg29,type=item_display,tag=this] facing entity @s feet positioned ^ ^ ^1 run tp @s ~ ~ ~ facing ^ ^ ^-1



execute store result score .count_seg LDVar1 if entity @e[tag=ldhitbox,tag=this,type=vex]
execute if score .count_seg LDVar1 < .ld_total_segment LDVar1 run tag @n[tag=this,tag=ldmain] add dead


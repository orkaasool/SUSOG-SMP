
# Timer
scoreboard players add @s LDTimer1 1
execute if score @s LDTimer1 matches 100.. run kill @s


# FX
execute rotated ~ ~90 run function ld112:fx/bluefire_boom
particle minecraft:smoke ~ ~ ~ 0.2 0.2 0.2 0.01 5 force
particle minecraft:end_rod ~ ~ ~ 0.2 0.2 0.2 0.01 1 force

# Chase player
execute if score @s LDTimer1 matches ..10 anchored eyes facing entity @p eyes positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^4 facing entity @s eyes facing ^ ^ ^-1 positioned as @s run tp @s ^ ^ ^0.5 ~ ~

tp @s ^ ^ ^0.725

# Hit Player
execute if score @s LDTimer1 matches 15.. positioned ~-1.5 ~-0.5 ~-1.5 as @a[dx=2,dz=2] positioned ~1 ~0.5 ~1 run damage @s 25 minecraft:mob_attack by @n[tag=ldragon,type=vex]
execute if score @s LDTimer1 matches 15.. positioned ~-1.5 ~-0.5 ~-1.5 if entity @p[dx=2,dz=2] positioned ~1 ~0.5 ~1 run function ld112:ld/states/bomb/boom

# Hit wall
execute if score @s LDTimer1 matches 15.. unless block ^ ^ ^0.75 #ld112:raycast_pass run function ld112:ld/states/bomb/boom









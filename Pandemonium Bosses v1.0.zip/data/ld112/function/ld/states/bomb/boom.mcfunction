
execute rotated ~ 0 positioned ~ ~ ~ run function ld112:fx/cloud_ground_boom
execute rotated ~ 0 positioned ~ ~ ~ run function ld112:fx/cloud_ground_boom_strong
particle minecraft:soul_fire_flame ~ ~ ~ 0.2 0.2 0.2 0.1 20 normal

summon creeper ~ ~ ~ {ignited:1,Fuse:0,ExplosionPower:1,CustomNameVisible:0b,CustomName:'{"text":"Deathmire\'s Soul Bomb"}'}
summon lightning_bolt

kill @s





# Bombing start

#Firing
summon marker ~ ~ ~ {CustomNameVisible:0b,Tags:["ld112","ldbomb","ld_init"],CustomName:'{"text":"Deathmire\'s Soul Bomb"}'}



execute as @e[tag=ld_init,type=marker] at @s run tp @s ~ ~ ~ facing entity @p


# FX
execute rotated ~ ~90 positioned ~ ~ ~ run function ld112:fx/cloud_ground_boom_force
execute as @a[distance=..300] at @s run playsound minecraft:entity.blaze.shoot hostile @s ~ ~ ~ 1 1 1





#IMPORTANT
tag @e[type=marker] remove ld_init




#scoreboard players set @s LDChoose 0


# Reset timer1
scoreboard players set @s LDTimer1 0
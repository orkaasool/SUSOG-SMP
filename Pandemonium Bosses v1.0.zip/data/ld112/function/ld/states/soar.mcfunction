
# Soar state

# Tick timer
scoreboard players add @s LDTimer1 1
scoreboard players add @s LDTimer2 1
scoreboard players add @s LDTimer3 1


# Teleport marker
execute if score @s LDTimer1 matches 1 at @p run spreadplayers ~ ~ 1 20 false @n[tag=ld_marker,tag=this,type=marker]
execute if score @s LDTimer1 matches 1 run execute as @e[tag=ld_marker,tag=this,type=marker] at @s run data modify entity @s Pos[1] set from entity @p Pos[1]
execute if score @s LDTimer1 matches 1 run execute as @e[tag=ld_marker,tag=this,type=marker] at @s run tp @s ~ ~22 ~

execute if score @s LDTimer1 matches 80.. run scoreboard players set @s LDTimer1 0


#------- Attacks -------

execute if score @s LDHealth matches 266.. if score @s LDTimer3 matches 120 unless score @s LDChoose matches 1.. run function ld112:ld/states/firebullet/shoot
execute if score @s LDHealth matches 266.. if score @s LDTimer3 matches 120 if score @s LDChoose matches 1 run function ld112:ld/states/aoe/shoot

execute if score @s LDHealth matches 134..265 if score @s LDTimer3 matches 95.. unless score @s LDChoose matches 1.. run function ld112:ld/states/firebullet/shoot
execute if score @s LDHealth matches 134..265 if score @s LDTimer3 matches 95.. if score @s LDChoose matches 1 run function ld112:ld/states/aoe/shoot

execute if score @s LDHealth matches ..133 if score @s LDTimer3 matches 80.. unless score @s LDChoose matches 1.. run function ld112:ld/states/firebullet/shoot
execute if score @s LDHealth matches ..133 if score @s LDTimer3 matches 80.. if score @s LDChoose matches 1 run function ld112:ld/states/aoe/shoot

#----------------------



# Chase marker
execute anchored eyes facing entity @n[tag=ld_marker,tag=this,type=marker] eyes positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^8 facing entity @s eyes facing ^ ^ ^-1 positioned as @s run tp @s ^ ^ ^0.5 ~ ~
tp @s ^ ^ ^0.75


# Change state
execute unless score @s LDHealth matches ..133 if score @s LDTimer2 matches 400.. run scoreboard players set @s LDState 2
execute unless score @s LDHealth matches ..133 if score @s LDTimer2 matches 400.. run scoreboard players set @s LDTimer1 0
execute unless score @s LDHealth matches ..133 if score @s LDTimer2 matches 400.. run scoreboard players set @s LDTimer3 0
execute unless score @s LDHealth matches ..133 if score @s LDTimer2 matches 400.. run scoreboard players set @s LDTimer2 0


execute if score @s LDHealth matches ..133 if score @s LDTimer2 matches 400.. unless score @s LDChoose matches 1.. run scoreboard players set @s LDState 3
execute if score @s LDHealth matches ..133 if score @s LDTimer2 matches 400.. if score @s LDChoose matches 1.. run scoreboard players set @s LDState 2
execute if score @s LDHealth matches ..133 if score @s LDTimer2 matches 400.. run scoreboard players set @s LDTimer1 0
execute if score @s LDHealth matches ..133 if score @s LDTimer2 matches 400.. run scoreboard players set @s LDTimer3 0
execute if score @s LDHealth matches ..133 if score @s LDTimer2 matches 400.. run scoreboard players set @s LDTimer2 0



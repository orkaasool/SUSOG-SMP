
# FX
execute rotated ~ ~90 positioned ~ ~ ~ run function ld112:fx/bluefire_boom_force
execute as @a[distance=..300] at @s run playsound minecraft:entity.wither.shoot hostile @s ~ ~ ~ 1 0.5 1

# Summon marker
summon marker ~ ~ ~ {CustomNameVisible:0b,Tags:["ld112","ld_aoemark","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Blaze"}'}
summon marker ~ ~ ~ {CustomNameVisible:0b,Tags:["ld112","ld_aoemark","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Blaze"}'}
summon marker ~ ~ ~ {CustomNameVisible:0b,Tags:["ld112","ld_aoemark","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Blaze"}'}
summon marker ~ ~ ~ {CustomNameVisible:0b,Tags:["ld112","ld_aoemark","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Blaze"}'}
summon marker ~ ~ ~ {CustomNameVisible:0b,Tags:["ld112","ld_aoemark","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Blaze"}'}

execute if score @s LDHealth matches ..200 run summon marker ~ ~ ~ {CustomNameVisible:0b,Tags:["ld112","ld_aoemark","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Blaze"}'}
execute if score @s LDHealth matches ..200 run summon marker ~ ~ ~ {CustomNameVisible:0b,Tags:["ld112","ld_aoemark","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Blaze"}'}

# Spread marker
execute unless score @s LDHealth matches ..200 run execute at @p run spreadplayers ~ ~ 5 10 false @e[tag=ld_init,tag=ld_aoemark,type=marker]
execute if score @s LDHealth matches ..200 run execute at @p run spreadplayers ~ ~ 5 13 false @e[tag=ld_init,tag=ld_aoemark,type=marker]

execute if score @s LDHealth matches ..200 at @p run tp @e[sort=random,tag=ld_init,tag=ld_aoemark,type=marker,limit=1] ~ ~ ~

execute as @e[tag=ld_init,tag=ld_aoemark,type=marker] at @s run data modify entity @s Pos[1] set from entity @p Pos[1]

execute as @e[tag=ld_init,tag=ld_aoemark,type=marker] at @s run function ld112:ld/states/aoe/upcast


#IMPORTANT
tag @e[type=marker] remove ld_init




scoreboard players set @s LDChoose 0


# Reset timer1
scoreboard players set @s LDTimer3 0
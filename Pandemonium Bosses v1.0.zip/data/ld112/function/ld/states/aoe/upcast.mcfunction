

#particle soul_fire_flame ~ ~ ~ 0.1 0.1 0.1 0.01 10 force


execute if block ~ ~ ~ #ld112:raycast_pass run function ld112:ld/states/aoe/downcast

execute if block ~ ~ ~ #ld112:raycast_pass run return 0



execute unless block ~ ~ ~ #ld112:raycast_pass positioned ~ ~1 ~ run function ld112:ld/states/aoe/upcast










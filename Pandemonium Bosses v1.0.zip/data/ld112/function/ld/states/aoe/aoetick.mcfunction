
# FX
#execute positioned ~ ~0.3 ~ run function ld112:ld/states/aoe/circleparticle
particle minecraft:soul_fire_flame ^ ^0.2 ^3 0 0 0 0.001 1 force
particle minecraft:soul_fire_flame ^ ^0.2 ^-3 0 0 0 0.001 1 force
particle minecraft:end_rod ~ ~6 ~ 0 4 0 0.01 1 force
particle minecraft:soul ~ ~0.2 ~ 1.5 0 1.5 0.1 1 force
tp @s ~ ~ ~ ~10 ~


#Timer
scoreboard players add @s LDTimer1 1
execute if score @s LDTimer1 matches 60.. run function ld112:ld/states/aoe/boom

#execute if block ~ ~-0.5 ~ #ld112:raycast_pass run tp @s ~ ~-0.5 ~
#execute unless block ~ ~ ~ #ld112:raycast_pass run tp @s ~ ~0.5 ~
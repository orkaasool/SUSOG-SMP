



# Damage player
execute positioned ~-3 ~-2 ~-2 as @e[dx=5,dz=3,dy=3,tag=!ldhitbox,type=!marker] run tag @s add get_damage_boi
execute positioned ~-2 ~-2 ~-3 as @e[dx=3,dz=5,dy=3,tag=!ldhitbox,type=!marker] run tag @s add get_damage_boi

execute as @e[tag=get_damage_boi] run damage @s 40 minecraft:mob_attack by @n[tag=ldragon,type=vex]
effect give @e[tag=get_damage_boi] minecraft:slowness 4 2

tag @e[tag=get_damage_boi] remove get_damage_boi


# FX
execute rotated ~ 0 run function ld112:fx/cloud_ground_boom
execute rotated ~ 0 run function ld112:fx/cloud_ground_boom_strong
execute rotated ~ 0 positioned ~ ~0.5 ~ run function ld112:fx/bluefire_boom
particle minecraft:soul_fire_flame ~ ~0.5 ~ 1 0.5 1 0.1 100 force
particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0.1 1 force

#summon creeper ~ ~0.7 ~ {ignited:1,Fuse:0,ExplosionPower:1,CustomNameVisible:0b,CustomName:'{"text":"Deathmire\'s Blaze"}'}
summon minecraft:lightning_bolt

kill @s







#particle flame ~ ~ ~ 0.1 0.1 0.1 0.01 10 force


execute positioned ~ ~-0.5 ~ unless block ~ ~ ~ #ld112:raycast_pass positioned ~ ~0.5 ~ run tp @s ~ ~ ~


execute positioned ~ ~-0.5 ~ unless block ~ ~ ~ #ld112:raycast_pass run return 0



execute positioned ~ ~-0.5 ~ if block ~ ~ ~ #ld112:raycast_pass run function ld112:ld/states/aoe/downcast










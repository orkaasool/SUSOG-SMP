execute store result score .x0 LDVar1 run data get entity @s Pos[0]
execute store result score .y0 LDVar1 run data get entity @s Pos[1]
execute store result score .z0 LDVar1 run data get entity @s Pos[2]

tp @s ^ ^ ^0.1

execute store result score .x1 LDVar1 run data get entity @s Pos[0]
execute store result score .y1 LDVar1 run data get entity @s Pos[1]
execute store result score .z1 LDVar1 run data get entity @s Pos[2]

tp @s ^ ^ ^-0.1


scoreboard players operation .x1 LDVar1 -= .x0 LDVar1
scoreboard players operation .y1 LDVar1 -= .y0 LDVar1
scoreboard players operation .z1 LDVar1 -= .z0 LDVar1


execute store result entity @s Motion[0] double 100 run scoreboard players get .x1 LDVar1
execute store result entity @s Motion[1] double 200 run scoreboard players get .y1 LDVar1
execute store result entity @s Motion[2] double 100 run scoreboard players get .z1 LDVar1

# Heaven state

scoreboard players add @s LDTimer1 1
scoreboard players add @s LDTimer2 1


# FX
execute if score @s LDTimer2 matches 1 at @p run playsound minecraft:entity.ender_dragon.ambient hostile @a ~ ~ ~ 1 1 1
#execute as @e[tag=lddisp,type=minecraft:item_display,tag=this] at @s run particle minecraft:soul_fire_flame ~ ~ ~ 0.3 0.3 0.3 0.01 1 force


# Teleport marker
execute if score @s LDTimer2 matches 10.. at @p run tp @n[tag=ld_marker,tag=this,type=marker] ~ ~20 ~

# Shoot bomb
execute if score @s LDTimer1 matches 20.. run function ld112:ld/states/bomb/shoot


# Chase marker
execute anchored eyes facing entity @n[tag=ld_marker,tag=this,type=marker] eyes positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^8 facing entity @s eyes facing ^ ^ ^-1 positioned as @s run tp @s ^ ^ ^0.5 ~ ~

tp @s ^ ^ ^0.75



# Change state
execute if score @s LDTimer2 matches 200.. run scoreboard players set @s LDState 1
execute if score @s LDTimer2 matches 200.. run scoreboard players set @s LDTimer1 0
execute if score @s LDTimer2 matches 200.. run scoreboard players set @s LDTimer3 0
execute if score @s LDTimer2 matches 200.. run scoreboard players set @s LDTimer2 0


# Dying state

# Tick timer
scoreboard players add @s LDTimer1 1

tag @s remove Boss

# Teleport marker
execute if score @s LDTimer1 matches 1 run execute as @e[tag=ld_marker,tag=this,type=marker] at @s run tp @s ~ ~30 ~
execute if score @s LDTimer1 matches 1 run advancement grant @a only ld112:ld/deathmire


# Chase marker
execute anchored eyes facing entity @n[tag=ld_marker,tag=this,type=marker] eyes positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^8 facing entity @s eyes facing ^ ^ ^-1 positioned as @s run tp @s ^ ^ ^0.5 ~ ~
tp @s ^ ^ ^0.5


# FX
execute if score @s LDTimer1 matches 1 run execute as @e[tag=ldsegs,type=item_display,tag=this] at @s run particle minecraft:explosion ~ ~ ~ 0 0 0 0.1 1 force
execute if score @s LDTimer1 matches 1 run playsound minecraft:entity.wither.death master @a ~ ~ ~ 1 1 1
execute if score @s LDTimer1 matches 1 run playsound minecraft:entity.ender_dragon.ambient master @a ~ ~ ~ 1 1 1

execute as @e[sort=random,limit=1,tag=ldsegs,type=item_display,tag=this] at @s run particle minecraft:explosion ~ ~ ~ 0 0 0 0.1 1 force
execute as @e[sort=random,limit=1,tag=ldsegs,type=item_display,tag=this] at @s rotated ~ 0 run function ld112:fx/cloud_ground_boom_force
#playsound minecraft:entity.generic.explode master @a ~ ~ ~ 0.6 1 1

execute if score @s LDTimer1 matches 100 at @e[tag=ldseg15,type=item_display,tag=this] run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0.1 1 force




# Death
execute if score @s LDTimer1 matches 100.. run summon item ~ ~ ~ {CustomNameVisible:1b,Invulnerable:1b,CustomName:'{"bold":true,"color":"yellow","text":"Loot Chest"}',Item:{id:"minecraft:chest",count:1,components:{"minecraft:max_stack_size":1,"minecraft:item_name":'{"bold":true,"color":"yellow","italic":false,"text":"Loot Chest"}',"minecraft:container_loot":{loot_table:"ld112:ld_drop"}}}}

execute if score @s LDTimer1 matches 100.. run kill @e[tag=ldragon,tag=this,tag=!ldmain]
execute if score @s LDTimer1 matches 100.. run kill @s


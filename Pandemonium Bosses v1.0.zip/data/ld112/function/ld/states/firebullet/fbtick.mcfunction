
# FX
particle minecraft:soul_fire_flame ~ ~ ~ 0.2 0.2 0.2 0.01 5 force
particle minecraft:smoke ~ ~ ~ 0.2 0.2 0.2 0.01 5 force
particle minecraft:end_rod ~ ~ ~ 0.2 0.2 0.2 0.01 1 force


#Timer
scoreboard players add @s LDTimer1 1
execute if score @s LDTimer1 matches 150.. run kill @s


# Chase player
execute if score @s LDTimer1 matches ..30 anchored eyes facing entity @p eyes positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^5 facing entity @s eyes facing ^ ^ ^-1 positioned as @s run tp @s ^ ^ ^0.5 ~ ~

tp @s ^ ^ ^0.8


# Hit Player
execute if score @s LDTimer1 matches 15.. positioned ~-0.5 ~-0.5 ~-0.5 as @a[dx=0] positioned ~0.5 ~0.5 ~0.5 run damage @s 10 minecraft:mob_attack by @n[tag=ldragon,type=vex]
execute if score @s LDTimer1 matches 15.. positioned ~-0.5 ~-0.5 ~-0.5 if entity @p[dx=0] positioned ~0.5 ~0.5 ~0.5 run function ld112:ld/states/firebullet/boom

# Hit wall
execute if score @s LDTimer1 matches 15.. unless block ~ ~ ~ #ld112:raycast_pass run function ld112:ld/states/firebullet/boom


#Firing
summon marker ^ ^0.1 ^ {CustomNameVisible:0b,Tags:["ld112","ld_firebullet","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Soul Cannon"}'}
summon marker ^0.1 ^-0.1 ^ {CustomNameVisible:0b,Tags:["ld112","ld_firebullet","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Soul Cannon"}'}
summon marker ^-0.1 ^-0.1 ^ {CustomNameVisible:0b,Tags:["ld112","ld_firebullet","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Soul Cannon"}'}

execute if score @s LDHealth matches ..200 run summon marker ^ ^-0.1 ^ {CustomNameVisible:0b,Tags:["ld112","ld_firebullet","ld_init"],CustomName:'{"italic":false,"text":"Deahtmire\'s Firebullet"}'}

execute as @e[tag=ld_init,type=marker] at @s run tp @s ~ ~ ~ facing entity @n[tag=ldmain,tag=this]

# FX
execute rotated ~ ~90 positioned ~ ~ ~ run function ld112:fx/bluefire_boom
execute as @a[distance=..300] at @s run playsound minecraft:entity.blaze.shoot hostile @s ~ ~ ~ 1 1 1

#IMPORTANT
tag @e[type=marker] remove ld_init


scoreboard players add @s LDChoose 1


# Reset timer1
scoreboard players set @s LDTimer3 0
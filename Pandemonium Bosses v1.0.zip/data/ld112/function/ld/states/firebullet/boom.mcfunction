
execute rotated ~ 0 positioned ~ ~0.4 ~ run function ld112:fx/bluefire_boom

summon creeper ~ ~ ~ {ignited:1,Fuse:0,ExplosionPower:0,CustomNameVisible:0b,CustomName:'{"text":"Deathmire\'s Soul Cannon"}',Silent:1b,Invulnerable:1b}
summon minecraft:lightning_bolt
particle minecraft:soul_fire_flame ~ ~ ~ 0.2 0.2 0.2 1 20 normal
kill @s





# Charge state

scoreboard players add @s LDTimer1 1
scoreboard players add @s LDTimer2 1


# FX
execute if score @s LDTimer1 matches 1 as @a[distance=..300] at @s run playsound minecraft:entity.ender_dragon.ambient hostile @s ~ ~ ~ 1 1 1

execute if score @s LDHealth matches ..199 if score @s LDTimer1 matches 40.. at @n[tag=this,tag=ldseg2,type=item_display] run function ld112:fx/cloud_ground_boom


# Teleport marker
execute if score @s LDTimer1 matches ..40 at @s rotated ~ 0 run tp @n[tag=ld_marker,tag=this,type=marker] ^ ^ ^1
execute if score @s LDTimer1 matches 40..60 at @p run tp @n[tag=ld_marker,tag=this,type=marker] ~ ~ ~



# Chase marker
execute anchored eyes facing entity @n[tag=ld_marker,tag=this,type=marker] eyes positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^2 facing entity @s eyes facing ^ ^ ^-1 positioned as @s run tp @s ^ ^ ^0.5 ~ ~
tp @s ^ ^ ^1
execute if score @s LDHealth matches ..199 if score @s LDTimer1 matches 40.. run tp @s ^ ^ ^1.25



# Breathe fire
#execute if score @s LDTimer1 matches 40.. run summon falling_block ^ ^ ^1 {BlockState:{Name:"minecraft:fire",Properties:{age:"0"}},Time:1,Tags:["ld112","ldfirebreathe","firebreath_init"]}

#execute as @e[tag=firebreath_init,type=falling_block] at @s run tp @s ~ ~ ~ facing entity @n[tag=ldmain,tag=this]
#execute as @e[tag=firebreath_init,type=falling_block] at @s run tp @s ~ ~ ~ facing ^ ^ ^-1
#execute as @e[tag=firebreath_init,type=falling_block] at @s run function ld112:ld/states/firebreath/aim

#tag @e[tag=firebreath_init] remove firebreath_init



# Catch up
execute if score @s LDTimer1 matches 40.. if entity @n[tag=ld_marker,tag=this,type=marker,distance=..2] run scoreboard players set @s LDTimer2 220



# Change state
execute if score @s LDTimer2 matches 220.. run scoreboard players set @s LDState 1
execute if score @s LDTimer2 matches 220.. run scoreboard players set @s LDTimer1 0
execute if score @s LDTimer2 matches 220.. run scoreboard players set @s LDTimer3 0
execute if score @s LDTimer2 matches 220.. run scoreboard players set @s LDTimer2 0


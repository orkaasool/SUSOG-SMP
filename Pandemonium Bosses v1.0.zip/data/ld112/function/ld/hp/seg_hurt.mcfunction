

# Get damage amount
execute store result score .c LDHealth run data get entity @s Health 1
scoreboard players operation .c LDHealth -= .max LDHealth
# Subtract Health
scoreboard players operation @e[tag=ldmain,type=item_display,tag=this] LDHealth += .c LDHealth

# Dead if hp score is zero or below
execute as @n[tag=ldmain,type=item_display,tag=this] if score @s LDHealth matches ..0 run tag @s add dead

# Get HP back
data modify entity @s Health set value 400


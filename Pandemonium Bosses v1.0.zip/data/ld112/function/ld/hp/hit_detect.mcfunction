# FX
particle block{block_state:"minecraft:black_wool"} ~ ~.25 ~ 0.5 0.5 0.5 1 10 normal
playsound minecraft:entity.ender_dragon.hurt hostile @a ~ ~ ~ 1 1 0.5
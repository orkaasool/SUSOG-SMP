
scoreboard players set @s LDTimer1 0
scoreboard players set @s LDState 420


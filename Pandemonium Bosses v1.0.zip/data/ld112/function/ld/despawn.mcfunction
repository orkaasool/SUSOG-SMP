
tp @e[tag=this] ~ -70 ~

kill @e[tag=this]
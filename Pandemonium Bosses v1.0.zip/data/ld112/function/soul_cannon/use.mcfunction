
advancement revoke @s only ld112:soul_spear_use

# Check Cooldown
execute if score @s SoulSpearCooldown matches 1.. run return 0

# Check Energy
execute unless score @s SoulSpearEnergy matches 25.. run title @s actionbar {"text":"Insufficient energy"}
execute unless score @s SoulSpearEnergy matches 25.. run return 0

# Get ID for player
execute unless score @s eggid matches 1.. run function ld112:get_id

# FX
execute positioned ~ ~1.5 ~ positioned ^ ^ ^2.5 rotated ~ ~90 run function ld112:fx/bluefire_boom
playsound minecraft:entity.blaze.shoot player @a ~ ~ ~ 1 1
# Shoot
execute positioned ~ ~1.5 ~ run summon marker ^ ^ ^2.5 {Tags:["ld112","p_soulcannon","init"]}
execute positioned ~ ~1.5 ~ rotated as @s run tp @e[tag=init] ^ ^ ^2.5 ~ ~
# Get ID for bullet
scoreboard players operation @n[tag=init] eggid = @s eggid

tag @e[tag=init] remove init

# Subtract Energy and Set Cooldown
scoreboard players remove @s SoulSpearEnergy 25
scoreboard players set @s SoulSpearCooldown 20





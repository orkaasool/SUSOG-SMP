
execute rotated ~ ~90 positioned ~ ~0.4 ~ run function ld112:fx/bluefire_boom

#summon creeper ~ ~ ~ {ignited:1,Fuse:0,ExplosionPower:0,CustomNameVisible:0b,CustomName:'{"text":"Soul Cannon"}'}

execute positioned ~-3 ~-0.5 ~-2 as @e[dx=5,dz=3,dy=1] run tag @s add get_damage_boi
execute positioned ~-2 ~-0.5 ~-3 as @e[dx=3,dz=5,dy=1] run tag @s add get_damage_boi

execute as @e[tag=get_damage_boi] run damage @s 4 minecraft:player_explosion by @p[tag=bullet_owner]
tag @e[tag=get_damage_boi] remove get_damage_boi



summon minecraft:lightning_bolt
particle minecraft:explosion ~ ~ ~ 0 0 0 1 1 normal
particle minecraft:soul_fire_flame ~ ~ ~ 0.2 0.2 0.2 1 20 normal
kill @s


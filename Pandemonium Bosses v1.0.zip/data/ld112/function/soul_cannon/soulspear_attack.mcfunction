

particle soul ~ ~0.5 ~ 0.5 0 0.5 0.01 3 normal

scoreboard players add @s SoulSpearEnergy 5
execute if score @s SoulSpearEnergy = .needed SoulSpearEnergy run title @s actionbar {"text":"Soul Cannon is ready","color":"aqua"}
execute if score @s SoulSpearEnergy = .needed SoulSpearEnergy run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.7 0.5
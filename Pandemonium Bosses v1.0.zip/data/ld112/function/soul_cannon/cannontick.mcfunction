
tag @s add myself

scoreboard players operation .this eggid = @s eggid
execute as @a if score @s eggid = .this eggid run tag @s add bullet_owner

# Timer
scoreboard players add @s LDTimer1 1
execute if score @s LDTimer1 matches 100.. run kill @s

# FX
particle minecraft:soul_fire_flame ~ ~ ~ 0.2 0.2 0.2 0.01 7 force
particle minecraft:smoke ~ ~ ~ 0.2 0.2 0.2 0.01 1 force
particle minecraft:end_rod ~ ~ ~ 0.2 0.2 0.2 0.01 3 force

# Move
tp @s ^ ^ ^0.8


# Hit
execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[dx=0,tag=!myself,tag=!bullet_owner,type=!item,type=!leash_knot,type=!marker] positioned ~0.5 ~0.5 ~0.5 run function ld112:soul_cannon/boom

execute unless block ~ ~ ~ #minecraft:air run function ld112:soul_cannon/boom



tag @s remove myself
tag @a remove bullet_owner


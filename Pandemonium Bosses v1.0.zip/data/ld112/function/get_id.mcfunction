
scoreboard players add .cur_id eggid 1
scoreboard players operation @s eggid = .cur_id eggid


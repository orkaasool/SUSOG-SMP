
# --------------------------------------------------------
# ----------------------- Functions ----------------------
# --------------------------------------------------------

execute as @e[tag=ldmain,type=item_display] at @s run function ld112:ld/headtick
execute as @e[tag=ldsegs] at @s run function ld112:ld/trailtick

#ld attacks
execute as @e[tag=ld_firebullet,type=marker] at @s run function ld112:ld/states/firebullet/fbtick
execute as @e[tag=ld_aoemark,type=marker] at @s run function ld112:ld/states/aoe/aoetick
execute as @e[tag=ldbomb,type=marker] at @s run function ld112:ld/states/bomb/btick
execute as @e[tag=ldbomb,type=marker] at @s run function ld112:ld/states/bomb/bmtick


# Remove the Boss Bar if Withered King doesn't exist
execute unless entity @e[tag=ldragon,type=item_display] run bossbar set minecraft:ldragon_bar visible false
bossbar set minecraft:ldragon_bar players @a

# Summoning
execute unless entity @e[tag=ldragon,type=item_display] as @e[type=item,nbt={Item:{id:"minecraft:white_dye",count:1,components:{"minecraft:custom_data":{ldsummon:1}}}}] at @s if block ~ ~-1 ~ beacon run function ld112:ld/summoning/item
execute as @e[type=marker,tag=ldsummonmark] at @s run function ld112:ld/summoning/marker


# Soul Spear Cooldown
execute as @a[scores={SoulSpearCooldown=1..}] run scoreboard players remove @s SoulSpearCooldown 1
execute as @e[tag=p_soulcannon,type=marker] at @s run function ld112:soul_cannon/cannontick


## Stages

# Stage 0
execute as @s[tag=!WKStage0] if score @s WKHealth matches ..300 run tellraw @a[distance=..200] ["",{"text":"\n"},{"text":"The Withered King has begun stage 1...","color":"red"},{"text":"\n "}]
execute as @s[tag=!WKStage0] if score @s WKHealth matches ..300 run tellraw @a[distance=..200] ["",{"text":"<"},{"text":"The Withered King, Blackburn","color":"#7959C2"},{"text":"> Are you a worthy opponent, or are you an arrogant vanguard? We shall see."}]

execute as @s[tag=!WKStage0] if score @s WKHealth matches ..300 run scoreboard players set @s WKStage 0
execute as @s[tag=!WKStage0] if score @s WKHealth matches ..300 run tag @s add WKStage0



# Stage 1
execute if score @s WKHealth matches ..250 if score @s WKStage matches 0 run scoreboard players set @s WKChoose 0
execute if score @s WKHealth matches ..250 if score @s WKStage matches 0 run scoreboard players set @s WKChooseTimer 0
execute if score @s WKHealth matches ..250 if score @s WKStage matches 0 run scoreboard players set @s WKStage 1


# Stage 2
execute if score @s WKStage matches 1 if score @s WKHealth matches ..200 run tellraw @a ["",{"text":"\n"},{"text":"The Withered King has begun stage 2...","color":"red"},{"text":"\n "}]
execute if score @s WKStage matches 1 if score @s WKHealth matches ..200 run scoreboard players set @s WKChoose 0
execute if score @s WKStage matches 1 if score @s WKHealth matches ..200 run scoreboard players set @s WKChooseTimer 0
execute if score @s WKStage matches 1 if score @s WKHealth matches ..200 run scoreboard players set @s WKStage 2


# Stage 3
execute if score @s WKStage matches 2 if score @s WKHealth matches ..150 run scoreboard players set @s WKChoose 0
execute if score @s WKStage matches 2 if score @s WKHealth matches ..150 run scoreboard players set @s WKChooseTimer 0
execute if score @s WKStage matches 2 if score @s WKHealth matches ..150 run scoreboard players set @s WKStage 3


# Stage 4
execute if score @s WKStage matches 3 if score @s WKHealth matches ..100 run tellraw @a ["",{"text":"\n"},{"text":"The Withered King has begun stage 3...","color":"red"},{"text":"\n "}]
execute if score @s WKStage matches 3 if score @s WKHealth matches ..100 run data merge entity @s {attributes:[{id:"minecraft:generic.movement_speed",base:0.305}]}
execute if score @s WKStage matches 3 if score @s WKHealth matches ..100 run scoreboard players set @s WKChoose 0
execute if score @s WKStage matches 3 if score @s WKHealth matches ..100 run scoreboard players set @s WKChooseTimer 0
execute if score @s WKStage matches 3 if score @s WKHealth matches ..100 run scoreboard players set @s WKStage 4



# Stage 5
execute if score @s WKStage matches 4 if score @s WKHealth matches ..50 run tellraw @a ["",{"text":"\n"},{"text":"The Withered King has begun the final stage...","color":"red"},{"text":"\n "}]
execute if score @s WKStage matches 4 if score @s WKHealth matches ..50 run data merge entity @s {attributes:[{id:"minecraft:generic.movement_speed",base:0.31}]}
execute if score @s WKStage matches 4 if score @s WKHealth matches ..50 run scoreboard players set @s WKChoose 0
execute if score @s WKStage matches 4 if score @s WKHealth matches ..50 run scoreboard players set @s WKChooseTimer 0
execute if score @s WKStage matches 4 if score @s WKHealth matches ..50 run scoreboard players set @s WKStage 5
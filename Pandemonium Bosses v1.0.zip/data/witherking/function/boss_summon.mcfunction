## Summonning Item Detection
execute as @e[type=item,nbt={Item:{id:"minecraft:apple",count:1,components:{"minecraft:custom_data":{WKSummon:1}}}}] unless entity @e[tag=WK,type=wither_skeleton] at @s if block ~ ~-1 ~ obsidian if block ~ ~-2 ~ soul_soil if block ~-1 ~-1 ~ soul_fire if block ~1 ~-1 ~ soul_fire if block ~ ~-1 ~1 soul_fire if block ~ ~-1 ~-1 soul_fire if block ~-1 ~-2 ~ soul_soil if block ~1 ~-2 ~ soul_soil if block ~ ~-2 ~1 soul_soil if block ~ ~-2 ~-1 soul_soil if block ~1 ~-2 ~1 soul_sand if block ~-1 ~-2 ~-1 soul_sand if block ~1 ~-2 ~-1 soul_sand if block ~-1 ~-2 ~1 soul_sand run tag @s add WKSummonItem


execute as @e[type=item,tag=WKSummonItem] at @s run function witherking:summoning_wk/summon_item_tick



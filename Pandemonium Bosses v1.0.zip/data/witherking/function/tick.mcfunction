
# --------------------------------------------------------
# ----------------------- Functions ----------------------
# --------------------------------------------------------

execute as @e[tag=laserbeaming] at @s run function witherking:abilities/laserbeam/main_tick

## Boss Generalist Functions
# Generals
execute as @e[tag=WK,type=wither_skeleton] at @s run function witherking:boss_general

# Theme
#function witherking:boss_theme

# Health Bar
function witherking:boss_bar

# Death
execute as @e[tag=WKDeathDetect] at @s run function witherking:boss_death
execute unless entity @e[tag=WKDeathDetect] run scoreboard players reset @e WKDeathTimer
# Note: loot is handled in death cutscene


## Boss Summon Function
function witherking:boss_summon

## Wraith
execute as @e[tag=WKWraith,type=vex] at @s run function witherking:wraith/wraith_tick
execute as @e[tag=WKWraithDisp,type=item_display] at @s run function witherking:wraith/wdisp_tick

##-------------------------- Boss Abilities --------------------------
execute unless entity @e[tag=WK] run scoreboard players reset @e WKChooseTimer

# Lightning Spell
execute as @e[tag=WKLightningSpellCircle,type=armor_stand] at @s run function witherking:abilities/lightning/magiccircle_tick

execute as @e[tag=WKLightningBat,type=bat] at @s run function witherking:abilities/lightning/bat_tick
execute as @e[tag=WKLightningArea,type=armor_stand] at @s run function witherking:abilities/lightning/area_tick

execute as @e[tag=WKLightningSpellMarker,type=armor_stand] at @s run function witherking:abilities/lightning/marker_tick
execute unless entity @e[tag=WKLightningSpellMarker,type=armor_stand] run scoreboard players reset @e[tag=WKLightningSpellMarker,type=armor_stand] WKLightningTimer


# Wither Skull 1
execute as @e[tag=WKskullToBe,type=marker] at @s run function witherking:abilities/wskull1/tobeskull_tick
execute as @e[tag=WKWitherSkull] run scoreboard players add @s WKTimer1 1
execute as @e[tag=WKWitherSkull] if score @s WKTimer1 matches 50.. run kill @s


# Summon Army 1
execute as @e[tag=WKSummonArmy1,type=bat] at @s run function witherking:abilities/army1/bat_tick

execute as @e[tag=WKArmy1,type=skeleton] at @s run function witherking:abilities/army1/soldier_tick1

execute as @e[tag=WKDigFX1,type=area_effect_cloud] at @s run particle block{block_state:"minecraft:dirt"} ~ ~ ~ 0.3 0 0.3 0.2 5 force


# Wither Skull 1
execute as @e[tag=WKSuperSkull,type=item_display] at @s run function witherking:abilities/wskull2/superskull_tick


#---------------------------------------------------------------------



# Boss Choose Abilities
#function witherking:boss_choose (Now handled in witherking:boss_general)

# Despawn when too far
#function witherking:boss_despawn (Now handled in witherking:boss_general)
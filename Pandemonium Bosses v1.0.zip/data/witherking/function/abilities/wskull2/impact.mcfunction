



summon minecraft:creeper ~ ~ ~ {ignited:1,Fuse:0,Invulnerable:1,Silent:1,CustomNameVisible:0b,CustomName:'"Super Wither Skull"'}
particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0.01 1 force



kill @s




# wskull 2 pick

# FX
execute positioned ~ ~1 ~ run function witherking:abilities/wskull1/smoke_boom_force
execute as @a[distance=..100] run playsound minecraft:entity.wither.shoot hostile @s ~ ~ ~ 1 0.5

## Summon the Marker
# execute positioned ~ ~3 ~ run summon marker ^0.5 ^ ^ {Tags:["WKskullToBe","WKProjectile","init"]}
# execute positioned ~ ~3 ~ run summon marker ^-0.5 ^ ^ {Tags:["WKskullToBe","WKProjectile","init"]}
# execute positioned ~ ~2 ~ run summon marker ^1.5 ^ ^ {Tags:["WKskullToBe","WKProjectile","init"]}
# execute positioned ~ ~2 ~ run summon marker ^-1.5 ^ ^ {Tags:["WKskullToBe","WKProjectile","init"]}

# execute as @e[tag=init] at @s run tp @s ~ ~ ~ facing entity @n[tag=this,tag=WK] feet
# execute as @e[tag=init] at @s run tp @s ~ ~ ~ facing ^ ^ ^-1

# # Set ID
# execute as @e[tag=init] run scoreboard players operation @s WKID = @n[tag=this,tag=WK] WKID

# tag @e remove init

# Add tag
tag @s add wskulling2


# Effect witherking
effect give @s minecraft:slowness 3 2 true


# Reset timer
scoreboard players set @s WKChooseTimer -70
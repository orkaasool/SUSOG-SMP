
# Timer
scoreboard players add @s WKTimer1 1

execute if score @s WKTimer1 matches 1 run scoreboard players set @s WKTimer1 39

# Summom marker
execute if score @s WKTimer1 matches 40 facing entity @p feet rotated ~ 0 positioned ^1.75 ^ ^ positioned ~ ~2 ~ run function witherking:abilities/wskull2/marker_summon
execute if score @s WKTimer1 matches 45 facing entity @p feet rotated ~ 0 positioned ^1.25 ^ ^ positioned ~ ~2.5 ~ run function witherking:abilities/wskull2/marker_summon
execute if score @s WKTimer1 matches 50 facing entity @p feet rotated ~ 0 positioned ^0.75 ^ ^ positioned ~ ~3 ~ run function witherking:abilities/wskull2/marker_summon

execute if score @s WKTimer1 matches 55 facing entity @p feet rotated ~ 0 positioned ^0.25 ^ ^ positioned ~ ~3.5 ~ run function witherking:abilities/wskull2/marker_summon
execute if score @s WKTimer1 matches 60 facing entity @p feet rotated ~ 0 positioned ^0.25 ^ ^ positioned ~ ~3.5 ~ run function witherking:abilities/wskull2/marker_summon

execute if score @s WKTimer1 matches 65 facing entity @p feet rotated ~ 0 positioned ^-0.75 ^ ^ positioned ~ ~3 ~ run function witherking:abilities/wskull2/marker_summon
execute if score @s WKTimer1 matches 70 facing entity @p feet rotated ~ 0 positioned ^-1.25 ^ ^ positioned ~ ~2.5 ~ run function witherking:abilities/wskull2/marker_summon
execute if score @s WKTimer1 matches 75 facing entity @p feet rotated ~ 0 positioned ^-1.75 ^ ^ positioned ~ ~2 ~ run function witherking:abilities/wskull2/marker_summon


execute if score @s WKTimer1 matches 40 run effect give @s minecraft:resistance 2 255 true

#execute if score @s WKTimer1 matches 100 facing entity @p feet rotated ~ 0 positioned ^ ^ ^1.5 positioned ~ ~5 ~ run function witherking:abilities/wskull2/superskull_summon


execute if score @s WKTimer1 matches 80.. run function witherking:abilities/wskull2/end



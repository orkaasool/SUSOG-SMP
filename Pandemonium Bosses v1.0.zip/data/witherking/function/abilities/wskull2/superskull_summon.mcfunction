
# SFX
playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 1 0.5

summon item_display ~ ~ ~ {Tags:["WKSuperSkull","WKProjectile","init"],teleport_duration:1,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.5f,0f],scale:[2f,2f,-2f]},item:{id:"minecraft:wither_skeleton_skull",count:1}}

# Face away from shooter
execute as @e[tag=init] at @s run tp @s ~ ~ ~ facing entity @p feet


# Set ID
execute as @e[tag=init] run scoreboard players operation @s WKID = @n[tag=this,tag=WK] WKID

tag @e remove init






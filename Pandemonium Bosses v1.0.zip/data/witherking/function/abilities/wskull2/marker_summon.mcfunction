

summon marker ~ ~ ~ {Tags:["WKskullToBe","WKProjectile","init"]}

execute as @e[tag=init] at @s run tp @s ~ ~ ~ facing entity @n[tag=this,tag=WK] feet
execute as @e[tag=init] at @s run tp @s ~ ~ ~ facing ^ ^ ^-1

# Set ID
execute as @e[tag=init] run scoreboard players operation @s WKID = @n[tag=this,tag=WK] WKID

tag @e remove init






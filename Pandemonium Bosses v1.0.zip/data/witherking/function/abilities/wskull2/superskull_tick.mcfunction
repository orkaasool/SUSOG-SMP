

# Timer
scoreboard players add @s WKTimer1 1

#Advance
tp @s ^ ^ ^0.75


# FX
particle minecraft:dust{color:[0.15,0.15,0.15],scale:2} ~ ~ ~ 0.7 0.7 0.7 0.01 10 force
particle minecraft:end_rod ~ ~ ~ 0.7 0.7 0.7 0.01 10 force



# Hit playerw
execute if score @s WKTimer1 matches 15.. positioned ~-0.5 ~-0.5 ~-0.5 if entity @p[dx=0] positioned ~0.5 ~0.5 ~0.5 run function witherking:abilities/wskull2/impact

# Hit wall
execute if score @s WKTimer1 matches 15.. unless block ^ ^ ^0.75 #ld112:raycast_pass run function witherking:abilities/wskull2/impact



# Expire
execute if score @s WKTimer1 matches 100.. run kill @s

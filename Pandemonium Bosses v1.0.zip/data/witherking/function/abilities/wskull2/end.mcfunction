






# Reset timer
scoreboard players set @s WKTimer1 0

# Add tag
tag @s remove wskulling2


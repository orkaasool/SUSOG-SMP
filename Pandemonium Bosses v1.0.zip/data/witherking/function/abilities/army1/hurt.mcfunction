


title @a[distance=..150] actionbar {"text":"Defeat his army to remove his shield.","color":"red"}

playsound minecraft:item.shield.block hostile @a ~ ~ ~ 1 2
playsound minecraft:block.anvil.place hostile @a ~ ~ ~ 0.4 1.6













# Army 1 pick

# FX
summon armor_stand ~ ~ ~ {Marker:1b,NoGravity:0b,Silent:1b,Invulnerable:1b,HasVisualFire:0b,Invisible:1b,Tags:["WKLightningSpellCircle","init"]}

summon marker ~ ~ ~ {Tags:["WKShieldParticle","init"]}

execute as @a[distance=..150] run playsound minecraft:entity.wither.shoot hostile @s ~ ~ ~ 1 0.5
execute as @a[distance=..150] run playsound minecraft:block.portal.travel ambient @s ~ ~ ~ 1 1 1

# Set ID
execute if score @s WKID matches 1.. as @e[tag=init] run scoreboard players operation @s WKID = @n[tag=this,tag=WK] WKID
tag @e remove init


# Slow down
effect give @s minecraft:slowness 10 3 true


# Speak
execute if score @s WKStage matches 0..3 run tellraw @a[distance=..200] ["",{"text":"<"},{"text":"The Withered King, Blackburn","color":"#7959C2"},{"text":"> Face the might of my army!"}]
execute if score @s WKStage matches 4..5 run tellraw @a[distance=..200] ["",{"text":"<"},{"text":"The Withered King, Blackburn","color":"#7959C2"},{"text":"> I call upon the creatures of ruin, destroy my enemy!"}]



# Add tag
tag @s add summon_army1


# Reset timer
scoreboard players set @s WKTimerA 0
scoreboard players set @s WKChooseTimer -150
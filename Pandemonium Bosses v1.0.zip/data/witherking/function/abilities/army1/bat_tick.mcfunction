
# Get ID
scoreboard players operation .this WKID = @s WKID
execute as @e if score @s WKID = .this WKID run tag @s add this


#Timer
scoreboard players add @s WKTimer1 1

#FX
execute if score @s WKTimer1 matches 10.. run particle soul ~ ~ ~ 0 0 0 0.01 1 force

execute if score @s WKTimer1 matches 10.. run tp @s ~ ~0.1 ~
# cast
execute if score @n[tag=this,tag=WK] WKStage matches 0..3 if score @s WKTimer1 matches 65.. run function witherking:abilities/army1/upcast
execute if score @n[tag=this,tag=WK] WKStage matches 4..5 if score @s WKTimer1 matches 65.. run function witherking:abilities/army1/summon3

# Kill self
execute if score @s WKTimer1 matches 65.. run kill @s




# Remove this tag
tag @e remove this


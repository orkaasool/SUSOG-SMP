
# Army 1 after_summon

# Shield FX
execute if score @s WKTimerAFX matches 10.. as @e[tag=WKShielder,tag=this] at @s facing entity @n[tag=WK,tag=this,type=minecraft:wither_skeleton] feet run function witherking:abilities/army1/raycast

execute if score @s WKTimerAFX matches 10.. as @e[tag=WKShieldParticle,tag=this,type=marker] at @s positioned ~ ~0.75 ~ rotated ~ ~90 run function witherking:abilities/army1/shield_particle1
execute if score @s WKTimerAFX matches 10.. as @e[tag=WKShieldParticle,tag=this,type=marker] at @s positioned ~ ~1.75 ~ rotated ~ ~90 run function witherking:abilities/army1/shield_particle
execute if score @s WKTimerAFX matches 10.. as @e[tag=WKShieldParticle,tag=this,type=marker] at @s positioned ~ ~2.75 ~ rotated ~ ~90 run function witherking:abilities/army1/shield_particle1

execute if score @s WKTimerAFX matches 10.. run scoreboard players set @s WKTimerAFX 0


# Shield
execute if score @s WKTimer1 matches 142 run effect give @s minecraft:resistance infinite 20



# Hurt
execute if entity @s[nbt={HurtTime:10s}] run function witherking:abilities/army1/hurt





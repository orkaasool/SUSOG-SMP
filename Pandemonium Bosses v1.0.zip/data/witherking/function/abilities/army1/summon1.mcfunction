
# Army 1 summon1

# Random weapon
execute store result score .ranres WKVar1 run random value 1..2

## Summon stage 1
# Sword
execute if score .ranres WKVar1 matches 1 align xyz positioned ~0.5 ~-2 ~0.5 run summon skeleton ~ ~ ~ {Silent:1b,Invulnerable:1b,NoAI:1b,CustomNameVisible:0b,DeathLootTable:"-",Tags:["WKShielder","WKArmy1","init"],CustomName:'"Foot Soldier"',HandItems:[{id:"minecraft:netherite_sword",count:1},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:"minecraft:netherite_chestplate",count:1},{id:"minecraft:netherite_helmet",count:1}],ArmorDropChances:[-327.670F,-327.670F,-327.670F,-327.670F],Health:20f,attributes:[{id:"minecraft:generic.max_health",base:20},{id:"minecraft:generic.attack_damage",base:5},{id:"minecraft:generic.follow_range",base:2048},{id:"minecraft:generic.jump_strength",base:0.5},{id:"minecraft:generic.movement_speed",base:0.31}],active_effects:[{id:"minecraft:fire_resistance",amplifier:1,duration:-1,show_particles:0b}]}
# Bow
execute if score .ranres WKVar1 matches 2 align xyz positioned ~0.5 ~-2 ~0.5 run summon skeleton ~ ~ ~ {Silent:1b,Invulnerable:1b,NoAI:1b,CustomNameVisible:0b,DeathLootTable:"-",Tags:["WKShielder","WKArmy1","init"],CustomName:'"Foot Soldier"',HandItems:[{id:"minecraft:bow",count:1},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:"minecraft:netherite_chestplate",count:1},{id:"minecraft:netherite_helmet",count:1}],ArmorDropChances:[-327.670F,-327.670F,-327.670F,-327.670F],Health:20f,attributes:[{id:"minecraft:generic.max_health",base:20},{id:"minecraft:generic.attack_damage",base:5},{id:"minecraft:generic.follow_range",base:2048},{id:"minecraft:generic.jump_strength",base:0.5},{id:"minecraft:generic.movement_speed",base:0.31}],active_effects:[{id:"minecraft:fire_resistance",amplifier:1,duration:-1,show_particles:0b}]}


# Set team
team join witherking_andfriends @e[tag=init]

# Set ID
execute if score @s WKID matches 1.. as @e[tag=init] run scoreboard players operation @s WKID = @n[tag=this,tag=WK] WKID
tag @e remove init

# Remove init tag
tag @e remove init



# FX
execute align xyz positioned ~0.5 ~ ~0.5 run summon area_effect_cloud ~ ~.2 ~ {Duration:50,Tags:["WKDigFX1"]}
execute align xyz positioned ~0.5 ~ ~0.5 run particle minecraft:witch ~ ~.2 ~ 0 0 0 0.1 20 force





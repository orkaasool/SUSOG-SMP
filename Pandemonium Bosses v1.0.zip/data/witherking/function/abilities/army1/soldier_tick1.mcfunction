
# Army 1 soldier_tick1

# Get ID
scoreboard players operation .this WKID = @s WKID
execute as @e if score @s WKID = .this WKID run tag @s add this


# Die if boss is gone
execute unless entity @n[tag=WK,tag=this,type=minecraft:wither_skeleton] run kill @s


# Make them immune to wither
effect clear @s wither







# Remove this tag
tag @e remove this


# Spawn animation goes below
execute if score @s WKTimer1 matches 42.. run return 0

scoreboard players add @s WKTimer1 1


execute if score @s WKTimer1 matches ..41 run tp @s ~ ~0.05 ~ 
execute if score @s WKTimer1 matches 41 run data merge entity @s {Invulnerable:0b}

# Make them angry at player
execute if score @s WKTimer1 matches 42 run damage @s 0.1 minecraft:player_attack by @p

execute if score @s WKTimer1 matches 42 run data merge entity @s {NoAI:0b,Silent:0b}


















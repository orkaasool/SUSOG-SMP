
# Army 1 summon3

# Randomize
#execute store result score .ranres WKVar1 run random value 1..2

## Summon stage 2
# Normal
#execute if score .ranres WKVar1 matches 1 align xyz positioned ~0.5 ~0.5 ~0.5 run function witherking:abilities/army1/upcast
#execute if score .ranres WKVar1 matches 1 align xyz positioned ~0.5 ~0.5 ~0.5 run return 0

# Wraith
execute if score .ranres WKVar1 matches 2 align xyz positioned ~0.5 ~-2 ~0.5 as @n[tag=this,tag=WK] run function witherking:wraith/summon_wraith


# FX
#execute align xyz positioned ~0.5 ~ ~0.5 run summon area_effect_cloud ~ ~.2 ~ {Duration:50,Tags:["WKDigFX1"]}
execute align xyz positioned ~0.5 ~ ~0.5 run particle minecraft:witch ~ ~.2 ~ 0 0 0 0.1 20 force





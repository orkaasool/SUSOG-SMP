


#particle flame ~ ~ ~ 0.1 0.1 0.1 0.01 10 force

# Summon
execute if score @n[tag=this,tag=WK] WKStage matches 0..1 positioned ~ ~-0.5 ~ unless block ~ ~ ~ #ld112:raycast_pass positioned ~ ~0.5 ~ run function witherking:abilities/army1/summon1

execute if score @n[tag=this,tag=WK] WKStage matches 2..5 positioned ~ ~-0.5 ~ unless block ~ ~ ~ #ld112:raycast_pass positioned ~ ~0.5 ~ run function witherking:abilities/army1/summon2


execute positioned ~ ~-0.5 ~ unless block ~ ~ ~ #ld112:raycast_pass run return 0



execute positioned ~ ~-0.5 ~ if block ~ ~ ~ #ld112:raycast_pass run function witherking:abilities/army1/downcast










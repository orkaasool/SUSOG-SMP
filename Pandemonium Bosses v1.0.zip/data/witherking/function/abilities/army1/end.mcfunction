
#data merge entity @s {NoAI:0,Invulnerable:0,HandItems:[{id:"minecraft:netherite_sword",count:1,components:{"minecraft:unbreakable":{},"minecraft:enchantments":{levels:{"minecraft:bane_of_arthropods":5,"minecraft:knockback":2,"minecraft:looting":3,"minecraft:sharpness":5,"minecraft:smite":5,"minecraft:sweeping_edge":3,"minecraft:mending":1,"minecraft:unbreaking":3}},"minecraft:enchantment_glint_override":false}},{}],ArmorItems:[{id:"minecraft:netherite_boots",count:1,components:{"minecraft:unbreakable":{},"minecraft:enchantments":{levels:{"minecraft:blast_protection":15,"minecraft:feather_falling":100,"minecraft:protection":6,"minecraft:thorns":3,"minecraft:depth_strider":3,"minecraft:soul_speed":4,"minecraft:mending":1,"minecraft:unbreaking":3}},"minecraft:enchantment_glint_override":false}},{id:"minecraft:netherite_leggings",count:1,components:{"minecraft:unbreakable":{},"minecraft:enchantments":{levels:{"minecraft:blast_protection":15,"minecraft:protection":6,"minecraft:thorns":3,"minecraft:swift_sneak":3,"minecraft:mending":1,"minecraft:unbreaking":3}},"minecraft:enchantment_glint_override":false,"minecraft:trim":{material:"minecraft:amethyst",pattern:"minecraft:rib"}}},{id:"minecraft:netherite_chestplate",count:1,components:{"minecraft:unbreakable":{},"minecraft:enchantments":{levels:{"minecraft:blast_protection":15,"minecraft:protection":6,"minecraft:thorns":3,"minecraft:mending":1,"minecraft:unbreaking":3}},"minecraft:enchantment_glint_override":false,"minecraft:trim":{material:"minecraft:amethyst",pattern:"minecraft:rib"}}},{id:"minecraft:white_dye",count:1,components:{"minecraft:unbreakable":{},"minecraft:custom_model_data":909,"minecraft:enchantments":{levels:{"minecraft:blast_protection":15,"minecraft:thorns":3,"minecraft:aqua_affinity":1,"minecraft:respiration":3,"minecraft:mending":1,"minecraft:unbreaking":3}},"minecraft:enchantment_glint_override":false,"minecraft:attribute_modifiers":[{id:"armor",type:"generic.armor",amount:3,operation:"add_value",slot:"head"},{id:"armor_toughness",type:"generic.armor_toughness",amount:3,operation:"add_value",slot:"head"},{id:"knockback_resistance",type:"generic.knockback_resistance",amount:1,operation:"add_value",slot:"head"}]}}]}


#FX
#particle smoke ~ ~1 ~ 0.2 0.5 0.2 0.1 100 force
#execute positioned ~ ~-2.5 ~ rotated ~ 0 run function witherking:abilities/shadow_move1/shadow_boom_force
#execute positioned ~ ~-0.5 ~ rotated ~ 0 run function witherking:abilities/shadow_move1/cloud_ground_boom_strong_force
#execute positioned ~ ~1 ~ rotated ~ 0 run function witherking:abilities/shadow_move1/shadow_boom_force
#execute as @a[distance=..150] run playsound minecraft:entity.wither.shoot hostile @s ~ ~ ~ 1 0.5 1


# Army 1 end

# Get rid of effect
#effect clear @s minecraft:slowness
effect clear @s minecraft:resistance

#FX
execute as @a[distance=..150] run playsound minecraft:block.glass.break ambient @s ~ ~ ~ 1 0.8 1
execute as @a[distance=..150] run playsound minecraft:block.glass.break ambient @s ~ ~ ~ 1 0.8 1
particle reverse_portal ~ ~1 ~ 0.2 0.5 0.2 2 100 force

# End the ability
scoreboard players set @s WKTimerA 0
scoreboard players set @s WKTimerAFX 0
tag @s remove summon_army1

particle dust{color:[0.573,0.031,1.000],scale:1} ^2.5000 ^0.0000 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^0.6292 ^-2.4195 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-2.1833 ^-1.2179 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-1.7282 ^1.8064 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^1.3133 ^2.1273 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^2.3893 ^-0.7356 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-0.1106 ^-2.4976 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-2.4450 ^-0.5216 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-1.1202 ^2.2350 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^1.8811 ^1.6466 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^2.0671 ^-1.4061 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-0.8406 ^-2.3545 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-2.4902 ^0.2209 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-0.4130 ^2.4657 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^2.2823 ^1.0202 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^1.5618 ^-1.9521 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-1.4962 ^-2.0029 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-2.3150 ^0.9439 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^0.3308 ^2.4780 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^2.4815 ^0.3035 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^0.9183 ^-2.3252 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-2.0193 ^-1.4740 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-1.9348 ^1.5833 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^1.0453 ^2.2710 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^2.4610 ^-0.4401 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^0.1935 ^-2.4925 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-2.3636 ^-0.8146 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-1.3832 ^2.0825 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^1.6673 ^1.8628 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^2.2225 ^-1.1448 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-0.5485 ^-2.4391 ^ 0 0 0 0.001 1
particle dust{color:[0.573,0.031,1.000],scale:1} ^-2.4986 ^-0.0830 ^ 0 0 0 0.001 1


# particle minecraft:electric_spark ^2.5000 ^0.0000 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^0.6292 ^-2.4195 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-2.1833 ^-1.2179 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-1.7282 ^1.8064 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^1.3133 ^2.1273 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^2.3893 ^-0.7356 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-0.1106 ^-2.4976 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-2.4450 ^-0.5216 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-1.1202 ^2.2350 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^1.8811 ^1.6466 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^2.0671 ^-1.4061 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-0.8406 ^-2.3545 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-2.4902 ^0.2209 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-0.4130 ^2.4657 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^2.2823 ^1.0202 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^1.5618 ^-1.9521 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-1.4962 ^-2.0029 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-2.3150 ^0.9439 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^0.3308 ^2.4780 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^2.4815 ^0.3035 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^0.9183 ^-2.3252 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-2.0193 ^-1.4740 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-1.9348 ^1.5833 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^1.0453 ^2.2710 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^2.4610 ^-0.4401 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^0.1935 ^-2.4925 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-2.3636 ^-0.8146 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-1.3832 ^2.0825 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^1.6673 ^1.8628 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^2.2225 ^-1.1448 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-0.5485 ^-2.4391 ^ 0 0 0 0.001 1
# particle minecraft:electric_spark ^-2.4986 ^-0.0830 ^ 0 0 0 0.001 1
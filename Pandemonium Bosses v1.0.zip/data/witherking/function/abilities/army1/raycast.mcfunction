




particle dust{color:[0.706,0.122,1.000],scale:1} ~ ~1 ~ 0 0 0 0.001 1 force

execute positioned ~-0.5 ~-0.5 ~-0.5 unless entity @n[tag=WK,tag=this,type=minecraft:wither_skeleton,dx=0] positioned ~0.5 ~0.5 ~0.5 facing entity @n[tag=WK,tag=this,type=minecraft:wither_skeleton] feet positioned ^ ^ ^0.5 run function witherking:abilities/army1/raycast



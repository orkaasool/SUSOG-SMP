
# Army 1 main_tick

#Timer
scoreboard players add @s WKTimerA 1
scoreboard players add @s WKTimerAFX 1


# Keep choose timer
#scoreboard players set @s WKChooseTimer -200


# TP shield marker close
execute as @e[tag=WKShieldParticle,tag=this,type=marker] at @s run tp @s ~ ~ ~ ~10 ~
tp @e[tag=WKShieldParticle,tag=this,type=marker] ~ ~ ~


## Summon bats
# Stage 0-3
execute if score @s WKStage matches 0..3 if score @s WKTimerA matches 30..35 run summon bat ~ ~3 ~ {Silent:1,Invulnerable:1,Tags:["WKSummonArmy1","init"],active_effects:[{id:"minecraft:invisibility",amplifier:2,duration:-1,show_particles:0b}]}
# Stage 4
execute if score @s WKStage matches 4.. if score @s WKTimerA matches 32..35 run summon bat ~ ~3 ~ {Silent:1,Invulnerable:1,Tags:["WKSummonArmy1","init"],active_effects:[{id:"minecraft:invisibility",amplifier:2,duration:-1,show_particles:0b}]}

# Set ID
execute as @e[tag=init] run scoreboard players operation @s WKID = @n[tag=this,tag=WK] WKID
tag @e remove init




# After summoning bats and troops
execute if score @s WKTimerA matches 143.. run function witherking:abilities/army1/after_summon


# End if no army left
execute if score @s WKTimerA matches 143.. unless entity @e[tag=WKShielder] run function witherking:abilities/army1/end



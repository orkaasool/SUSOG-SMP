# Timer
scoreboard players add @s WKLightningAreaTimer 1

# FX
tp @s ~ ~ ~ ~9 ~
particle minecraft:soul_fire_flame ^ ^ ^3 0 0 0 0 1 force
particle minecraft:soul_fire_flame ^ ^ ^-3 0 0 0 0 1 force

# Make the Area Markers grounded
execute if block ~ ~-1 ~ #ld112:raycast_pass run tp @s ~ ~-.2 ~
execute unless block ~ ~ ~ #ld112:raycast_pass run tp @s ~ ~1 ~


execute if score @s WKLightningAreaTimer matches 30 at @s run kill @s

scoreboard players add @s WKLightningTimer 1

tp @s ~ ~ ~ ~.2 ~
execute positioned ~ ~0.5 ~ run function witherking:abilities/lightning/magiccircle

execute if score @s WKLightningTimer matches 80.. run kill @s
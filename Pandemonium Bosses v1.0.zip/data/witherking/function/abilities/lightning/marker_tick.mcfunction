
# Get ID
scoreboard players operation .this WKID = @s WKID
execute as @e if score @s WKID = .this WKID run tag @s add this

## Timer
scoreboard players add @s WKLightningTimer 1


## Summon Mark Armor Stand for circle
execute if score @s WKLightningTimer matches 5 run summon armor_stand ~ ~ ~ {Marker:1b,NoGravity:0b,Silent:1b,Invulnerable:1b,HasVisualFire:0b,Invisible:1b,Tags:["WKLightningMark"]}

## Lightning Circle
# Particles
execute as @e[tag=WKLightningMark] at @s run particle minecraft:soul ^ ^ ^12 0 0 0 0 5 force
execute as @e[tag=WKLightningMark] at @s run particle minecraft:soul ^ ^ ^-12 0 0 0 0 5 force
# Rotation
execute as @e[tag=WKLightningMark] at @s run tp @s ~ ~ ~ ~3 ~

# Kill Mark Armor Stand
execute if score @s WKLightningTimer matches 65 run kill @e[tag=WKLightningMark]



# Summon Bats
execute if score @s WKLightningTimer matches 6..64 at @e[tag=WKLightningMark] run summon bat ^ ^ ^12 {Silent:1b,Invulnerable:1b,PersistenceRequired:1b,Health:999f,Motion:[0.0,0.0,0.0],Tags:["WKLightningBat"],active_effects:[{id:"minecraft:invisibility",amplifier:255,duration:-1,show_particles:0b,show_icon:0b,ambient:0b}],attributes:[{id:"minecraft:generic.max_health",base:999},{id:"minecraft:generic.burning_time",base:0}]}
execute if score @s WKLightningTimer matches 6..64 at @e[tag=WKLightningMark] run summon bat ^ ^ ^-12 {Silent:1b,Invulnerable:1b,PersistenceRequired:1b,Health:999f,Motion:[0.0,0.0,0.0],Tags:["WKLightningBat"],active_effects:[{id:"minecraft:invisibility",amplifier:255,duration:-1,show_particles:0b,show_icon:0b,ambient:0b}],attributes:[{id:"minecraft:generic.max_health",base:999},{id:"minecraft:generic.burning_time",base:0}]}


# Note: Bat's tick is handled in bat_tick
# Note: Area's tick is handled in area_tick


## Action Bar Countdown
execute if score @s WKLightningTimer matches 5 run title @a actionbar {"text":"Impending Lightning Spell in 5 seconds.","color":"red"}
execute if score @s WKLightningTimer matches 25 run title @a actionbar {"text":"Impending Lightning Spell in 4 seconds.","color":"red"}
execute if score @s WKLightningTimer matches 45 run title @a actionbar {"text":"Impending Lightning Spell in 3 seconds.","color":"red"}
execute if score @s WKLightningTimer matches 65 run title @a actionbar {"text":"Impending Lightning Spell in 2 seconds.","color":"red"}
execute if score @s WKLightningTimer matches 85 run title @a actionbar {"text":"Impending Lightning Spell in 1 second.","color":"red"}


## Give Resistance and then Remove Tag
execute if score @s WKLightningTimer matches 105 run effect give @n[tag=WK,tag=this] minecraft:resistance 5 255 true

# Kill self
execute if score @s WKLightningTimer matches 107 run kill @s
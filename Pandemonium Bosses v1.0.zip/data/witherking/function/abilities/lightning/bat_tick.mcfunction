
# Bat Tick
# Bat Particles
execute if score @s WKLightningBatTimer matches ..65 at @s run particle minecraft:soul ~ ~ ~ 0 0 0 0 1 force
# execute as @e[tag=WKLightningBat] at @s run particle minecraft:reverse_portal ^ ^ ^-12 1 1 1 .2 7 force

# Bat Timer and Explode
scoreboard players add @s WKLightningBatTimer 1

execute if score @s WKLightningBatTimer matches 104.. at @s run execute as @e[tag=!WK,distance=..3] unless entity @s[tag=WKShielder] run damage @s 40 minecraft:lightning_bolt
execute if score @s WKLightningBatTimer matches 105 at @s run summon minecraft:lightning_bolt ~ ~ ~
execute if score @s WKLightningBatTimer matches 105 at @s run particle cloud ~ ~ ~ 0 0 0 0.2 25 force
# execute as @e[tag=WKLightningBat] if score @s WKLightningBatTimer matches 125 at @s run summon creeper ~ ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,ExplosionRadius:1b,Fuse:0,ignited:1b,CustomName:'{"text":"Lightning Spell"}'}


# Summon Area Marker
execute if score @s WKLightningBatTimer matches 85 at @s run data merge entity @s {NoGravity:1b,NoAI:1b,Health:999f,Motion:[0.0,0.0,0.0],attributes:[{id:"minecraft:generic.max_health",base:999},{id:"minecraft:generic.burning_time",base:0}]}

execute if score @s WKLightningBatTimer matches 85 at @s run summon armor_stand ~ ~ ~ {Marker:1b,NoGravity:0b,Silent:1b,Invulnerable:1b,HasVisualFire:0b,Invisible:1b,Tags:["WKLightningArea"]}




# Note: Area's tick is handled in area_tick

# Make the Bats grounded
execute if block ~ ~-1 ~ #ld112:raycast_pass run tp @s ~ ~-.5 ~
execute unless block ~ ~ ~ #ld112:raycast_pass run tp @s ~ ~1 ~

# Kill the Bats
execute if score @s WKLightningBatTimer matches 106 at @s run tp @s ~ ~-5000 ~
execute if score @s WKLightningBatTimer matches 107 at @s run kill @s



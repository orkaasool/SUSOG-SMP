
# Lightning pick

## Summon the Marker
execute at @p run summon armor_stand ~ ~10 ~ {Marker:1b,NoGravity:0b,Silent:1b,Invulnerable:1b,HasVisualFire:0b,Invisible:1b,Tags:["WKLightningSpellMarker","init"]}
execute at @p run summon armor_stand ~ ~10 ~ {Marker:1b,NoGravity:0b,Silent:1b,Invulnerable:1b,HasVisualFire:0b,Invisible:1b,Tags:["WKLightningSpellCircle","init"]}

# Set ID
scoreboard players operation @e[tag=init] WKID = @s WKID
tag @e remove init


scoreboard players set @s WKChooseTimer -100

## Timer
scoreboard players add @s WKChooseTimer 1

## Randomizer
#execute if entity @s[tag=WKStage0] if score @s WKChooseTimer matches 150 run execute store result score @s WKChoose run random value 1..10


## Abilities

# Stage 0
execute if score @s WKChooseTimer matches 150.. run function witherking:abilities/shadow_move2/pick

# Timer
scoreboard players add @s WKTimer1 1

# FX
particle minecraft:dust{color:[0.15,0.15,0.15],scale:1} ~ ~ ~ 0.2 0.2 0.2 0.01 4 force
particle minecraft:reverse_portal ~ ~ ~ 0.2 0.2 0.2 0.01 4 force

# Move
tp @s ^ ^ ^0.3

# Aim
execute if score @s WKTimer1 matches 19.. run tp @s ~ ~ ~ facing entity @p
execute if score @s WKTimer1 matches 19.. run function witherking:abilities/wskull1/aim


# FX
execute if score @s WKTimer1 matches 20.. run particle minecraft:smoke ~ ~ ~ 0 0 0 0.2 30 force
execute if score @s WKTimer1 matches 20.. run playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 1 1
execute if score @s WKTimer1 matches 20.. rotated ~ ~90 run function witherking:abilities/wskull1/smoke_boom_force
execute if score @s WKTimer1 matches 20.. run particle minecraft:reverse_portal ~ ~ ~ 0 0 0 0.2 20 force
# Summon skull
execute if score @s WKTimer1 matches 20.. run function witherking:abilities/wskull1/shoot with storage minecraft:aim

execute if score @s WKTimer1 matches 20.. run kill @s
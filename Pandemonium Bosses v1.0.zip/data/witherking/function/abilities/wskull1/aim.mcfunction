execute store result score .x0 WKVar1 run data get entity @s Pos[0] 100
execute store result score .y0 WKVar1 run data get entity @s Pos[1] 100
execute store result score .z0 WKVar1 run data get entity @s Pos[2] 100

tp @s ^ ^ ^1

execute store result score .x1 WKVar1 run data get entity @s Pos[0] 100
execute store result score .y1 WKVar1 run data get entity @s Pos[1] 100
execute store result score .z1 WKVar1 run data get entity @s Pos[2] 100

#tp @s ^ ^ ^-1

scoreboard players operation .x1 WKVar1 -= .x0 WKVar1
scoreboard players operation .y1 WKVar1 -= .y0 WKVar1
scoreboard players operation .z1 WKVar1 -= .z0 WKVar1


execute store result storage aim Motion[0] double 0.005 run scoreboard players get .x1 WKVar1
execute store result storage aim Motion[1] double 0.005 run scoreboard players get .y1 WKVar1
execute store result storage aim Motion[2] double 0.005 run scoreboard players get .z1 WKVar1
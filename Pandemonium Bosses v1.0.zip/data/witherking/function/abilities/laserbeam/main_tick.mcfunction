

# laserbeam main_tick

# Timer
scoreboard players add @s WKTimer1 1
scoreboard players add @s WKTimer2 1

execute if score @s WKTimer1 matches ..80 run run function witherking:abilities/lightning/magiccircle

execute positioned ~ ~1.5 ~ if score @s WKTimer1 matches 20 run function witherking:abilities/laserbeam/ccircle1.8
execute positioned ~ ~1.5 ~ if score @s WKTimer1 matches 30 run function witherking:abilities/laserbeam/ccircle1.4
execute positioned ~ ~1.5 ~ if score @s WKTimer1 matches 40 run function witherking:abilities/laserbeam/ccircle1.2
execute positioned ~ ~1.5 ~ if score @s WKTimer1 matches 50 run function witherking:abilities/laserbeam/ccircle1
execute positioned ~ ~1.5 ~ if score @s WKTimer1 matches 60 run function witherking:abilities/laserbeam/ccircle0.8
execute positioned ~ ~1.5 ~ if score @s WKTimer1 matches 70 run function witherking:abilities/laserbeam/ccircle0.6
execute positioned ~ ~1.5 ~ if score @s WKTimer1 matches 80 run function witherking:abilities/laserbeam/ccircle0.4


execute if score @s WKTimer1 matches 200.. run function witherking:abilities/laserbeam/end



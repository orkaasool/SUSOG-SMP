



# Make WK move again
data merge entity @s {NoAI:0b}

# Reset timer
scoreboard players set @s WKTimer1 0
scoreboard players set @s WKTimer2 0

# Add tag
tag @s remove laserbeaming


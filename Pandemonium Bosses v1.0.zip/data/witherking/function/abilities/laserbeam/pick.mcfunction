
# laserbeam 2 pick

# FX
execute positioned ~ ~1 ~ run function witherking:abilities/wskull1/smoke_boom_force
execute as @a[distance=..100] run playsound minecraft:entity.wither.shoot hostile @s ~ ~ ~ 1 0.5


# Add tag
tag @s add laserbeaming


# Stops witherking from moving
data merge entity @s {NoAI:1b}


# Reset timer
scoreboard players set @s WKChooseTimer -100
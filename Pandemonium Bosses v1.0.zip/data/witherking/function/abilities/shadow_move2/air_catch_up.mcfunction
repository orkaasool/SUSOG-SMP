

scoreboard players add @s WKSDStage 1
scoreboard players set @s WKTimerSD 19
tp @s @n[tag=sm1_destination,tag=this]

execute as @a[distance=..100] run playsound minecraft:entity.wither.shoot hostile @s ~ ~ ~ 1 0.5





# Return if SDStage 5
execute if score @s WKSDStage matches 6.. run return 0

## Summon the Marker
execute facing entity @p feet run summon marker ^0.5 ^ ^ {Tags:["WKskullToBe","WKProjectile","init"]}
execute facing entity @p feet run summon marker ^-0.5 ^ ^ {Tags:["WKskullToBe","WKProjectile","init"]}
execute facing entity @p feet run summon marker ^ ^-0.5 ^ {Tags:["WKskullToBe","WKProjectile","init"]}
execute facing entity @p feet run summon marker ^ ^0.5 ^ {Tags:["WKskullToBe","WKProjectile","init"]}

scoreboard players set @e[tag=init] WKTimer1 5

execute as @e[tag=init] at @s run tp @s ~ ~ ~ facing entity @n[tag=this,tag=WK] feet
execute as @e[tag=init] at @s run tp @s ~ ~ ~ facing ^ ^ ^-1

# Set ID
execute as @e[tag=init] run scoreboard players operation @s WKID = @n[tag=this,tag=WK] WKID

tag @e remove init

summon lightning_bolt ~7.0000 ~ ~0.0000
summon lightning_bolt ~1.0798 ~ ~-6.9162
summon lightning_bolt ~-6.6669 ~ ~-2.1337
summon lightning_bolt ~-3.1365 ~ ~6.2580
summon lightning_bolt ~5.6993 ~ ~4.0643
summon lightning_bolt ~4.8948 ~ ~-5.0041
summon lightning_bolt ~-4.1892 ~ ~-5.6081
summon lightning_bolt ~-6.1871 ~ ~3.2740
summon lightning_bolt ~2.2805 ~ ~6.6181
summon lightning_bolt ~6.8907 ~ ~-1.2323
summon lightning_bolt ~-0.1547 ~ ~-6.9983
summon lightning_bolt ~-6.9384 ~ ~-0.9267


summon lightning_bolt ~4.7279 ~ ~7.6581
summon lightning_bolt ~8.2958 ~ ~-3.4900
summon lightning_bolt ~-2.1686 ~ ~-8.7348
summon lightning_bolt ~-8.9648 ~ ~0.7953
summon lightning_bolt ~-0.5970 ~ ~8.9802
summon lightning_bolt ~8.7806 ~ ~1.9751
summon lightning_bolt ~3.3059 ~ ~-8.3709
summon lightning_bolt ~-7.7607 ~ ~-4.5575
summon lightning_bolt ~-5.7001 ~ ~6.9648
summon lightning_bolt ~6.0022 ~ ~6.7062
summon lightning_bolt ~7.5518 ~ ~-4.8960
summon lightning_bolt ~-3.6725 ~ ~-8.2166
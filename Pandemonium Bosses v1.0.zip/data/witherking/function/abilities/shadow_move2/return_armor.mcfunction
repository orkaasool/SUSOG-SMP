
data merge entity @s {NoAI:0,Invulnerable:0,HandItems:[{id:"minecraft:netherite_sword",count:1,components:{"minecraft:unbreakable":{},"minecraft:enchantments":{levels:{"minecraft:bane_of_arthropods":5,"minecraft:knockback":2,"minecraft:looting":3,"minecraft:sharpness":5,"minecraft:smite":5,"minecraft:sweeping_edge":3,"minecraft:mending":1,"minecraft:unbreaking":3}},"minecraft:enchantment_glint_override":false}},{}],ArmorItems:[{id:"minecraft:netherite_boots",count:1,components:{"minecraft:unbreakable":{},"minecraft:enchantments":{levels:{"minecraft:blast_protection":15,"minecraft:feather_falling":100,"minecraft:protection":6,"minecraft:depth_strider":3,"minecraft:soul_speed":4,"minecraft:mending":1,"minecraft:unbreaking":3}},"minecraft:enchantment_glint_override":false}},{id:"minecraft:netherite_leggings",count:1,components:{"minecraft:unbreakable":{},"minecraft:enchantments":{levels:{"minecraft:blast_protection":15,"minecraft:protection":6,"minecraft:swift_sneak":3,"minecraft:mending":1,"minecraft:unbreaking":3}},"minecraft:enchantment_glint_override":false,"minecraft:trim":{material:"minecraft:amethyst",pattern:"minecraft:rib"}}},{id:"minecraft:netherite_chestplate",count:1,components:{"minecraft:unbreakable":{},"minecraft:enchantments":{levels:{"minecraft:blast_protection":15,"minecraft:protection":6,"minecraft:mending":1,"minecraft:unbreaking":3}},"minecraft:enchantment_glint_override":false,"minecraft:trim":{material:"minecraft:amethyst",pattern:"minecraft:rib"}}},{id:"minecraft:white_dye",count:1,components:{"minecraft:unbreakable":{},"minecraft:custom_model_data":909,"minecraft:enchantments":{levels:{"minecraft:blast_protection":15,"minecraft:aqua_affinity":1,"minecraft:respiration":3,"minecraft:mending":1,"minecraft:unbreaking":3}},"minecraft:enchantment_glint_override":false,"minecraft:attribute_modifiers":[{id:"armor",type:"generic.armor",amount:3,operation:"add_value",slot:"head"},{id:"armor_toughness",type:"generic.armor_toughness",amount:3,operation:"add_value",slot:"head"},{id:"knockback_resistance",type:"generic.knockback_resistance",amount:1,operation:"add_value",slot:"head"}]}}]}

# Immediately shoot wither skulls
#execute facing entity @p feet run function witherking:abilities/shadow_move1/shoot_skull

# Shadow move 2 return_armor

#FX
execute as @a[distance=..150] run playsound minecraft:entity.lightning_bolt.impact ambient @s ~ ~ ~ 1 1 1
execute rotated ~ 0 run function witherking:abilities/shadow_move1/cloud_ground_boom_strong_force
particle minecraft:explosion_emitter ~ ~ ~

# Break blocks
function witherking:misc/break_block_around_ifmobgrief

# Lightning
function witherking:abilities/shadow_move2/lightning_circle


# Damage player
execute positioned ~-3 ~-2 ~-2 as @a[dx=5,dz=3,dy=3] run tag @s add get_damage_boi
execute positioned ~-2 ~-2 ~-3 as @a[dx=3,dz=5,dy=3] run tag @s add get_damage_boi

execute as @e[tag=get_damage_boi] run damage @s 40 minecraft:mob_attack by @n[tag=WK,tag=this]

tag @e[tag=get_damage_boi] remove get_damage_boi




# Get rid of marker
kill @e[tag=sm1_destination,tag=this]
# Get rid of invisibility
effect clear @s minecraft:invisibility

# End the ability
scoreboard players set @s WKTimerSD 0
scoreboard players set @s WKSDStage 1
tag @s remove shadow_moving2
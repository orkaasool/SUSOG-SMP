

$summon wither_skull ~ ~ ~ {Tags:["WKWitherSkull"],acceleration_power:0.1d,dangerous:0b,Motion:$(Motion)}

#$say $(text)
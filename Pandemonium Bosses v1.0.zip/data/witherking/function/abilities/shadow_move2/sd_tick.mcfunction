
# Shadow move 2 sd_tick



#Timer
scoreboard players add @s WKTimerSD 1


# WK FX
particle minecraft:smoke ~ ~ ~ 0.4 0.4 0.4 0.01 40 force
particle minecraft:end_rod ~ ~ ~ 0.4 0.4 0.4 0.01 1 force



# Positioning Marker Destination
execute if score @s WKTimerSD matches ..20 if score @s WKSDStage matches 1 at @p run tp @n[tag=sm1_destination,tag=this] ~ ~10 ~20
execute if score @s WKTimerSD matches ..20 if score @s WKSDStage matches 2 at @p run tp @n[tag=sm1_destination,tag=this] ~20 ~10 ~
execute if score @s WKTimerSD matches ..20 if score @s WKSDStage matches 3 at @p run tp @n[tag=sm1_destination,tag=this] ~ ~10 ~-20
execute if score @s WKTimerSD matches ..20 if score @s WKSDStage matches 4 at @p run tp @n[tag=sm1_destination,tag=this] ~-20 ~10 ~
execute if score @s WKTimerSD matches ..20 if score @s WKSDStage matches 5 at @p run tp @n[tag=sm1_destination,tag=this] ~ ~30 ~

execute if score @s WKTimerSD matches ..20 if score @s WKSDStage matches 6 at @p run tp @n[tag=sm1_destination,tag=this] ~ ~ ~


# Marker Destination FX
execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:end_rod ^4 ^.5 ^ 0 0 0 0.001 1 force
execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:soul_fire_flame ^-4 ^.5 ^ 0 0 0 0.001 1 force

execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:firework ^10 ^.5 ^ 0 0 0 0.001 1 force
execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:firework ^-10 ^.5 ^ 0 0 0 0.001 1 force
execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:firework ^ ^.5 ^10 0 0 0 0.001 1 force
execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:firework ^ ^.5 ^-10 0 0 0 0.001 1 force

execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s if block ~ ~-0.2 ~ #ld112:raycast_pass run tp @s ~ ~-0.2 ~
execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s if block ~ ~-1 ~ #ld112:raycast_pass run tp @s ~ ~-1 ~
execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run tp @s ~ ~ ~ ~20 ~





# Face marker
execute if score @s WKTimerSD matches 20.. run tp @s ~ ~ ~ facing entity @n[tag=sm1_destination,tag=this] feet

# Advance!
tp @s ^ ^ ^1



## Catch up
# 1-5
execute if score @s WKSDStage matches 1..5 if score @s WKTimerSD matches 21.. if entity @n[tag=sm1_destination,tag=this,distance=..1.8] run function witherking:abilities/shadow_move2/air_catch_up

# Last Dive
execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 21.. if entity @n[tag=sm1_destination,tag=this,distance=..1.8] run tp @s @n[tag=sm1_destination,tag=this]
execute if score @s WKSDStage matches 6 if score @s WKTimerSD matches 21.. if entity @n[tag=sm1_destination,tag=this,distance=..1.8] run function witherking:abilities/shadow_move2/return_armor



# Keep timer
scoreboard players set @s WKChooseTimer -50





## Timer
scoreboard players add @s WKChooseTimer 1

## Randomizer
#execute if entity @s[tag=WKStage0] if score @s WKChooseTimer matches 150 run execute store result score @s WKChoose run random value 1..10


## Abilities

# Stage 0
execute if score @s WKStage matches 0 if score @s WKChooseTimer matches 1 run scoreboard players add @s WKChoose 1
# Cycle
execute if score @s WKStage matches 0 if score @s WKChooseTimer matches 1.. if score @s WKChoose matches 4.. run scoreboard players set @s WKChoose 1

execute if score @s WKStage matches 0 if score @s WKChooseTimer matches 150.. if score @s WKChoose matches 1 if entity @p[distance=..13] run function witherking:abilities/lightning/pick
execute if score @s WKStage matches 0 if score @s WKChooseTimer matches 150.. if score @s WKChoose matches 1 unless entity @p[distance=..13] run function witherking:abilities/shadow_move1/pick

execute if score @s WKStage matches 0 if score @s WKChooseTimer matches 130.. if score @s WKChoose matches 2..3 run function witherking:abilities/wskull1/pick
# End Cycle



# Stage 1
execute if score @s WKStage matches 1 if score @s WKChooseTimer matches 1 run scoreboard players add @s WKChoose 1
# Summon Army
execute if score @s WKStage matches 1 if score @s WKChooseTimer matches 50.. if score @s WKChoose matches 1 run function witherking:abilities/army1/pick

# Cycle
execute if score @s WKStage matches 1 if score @s WKChooseTimer matches 1.. if score @s WKChoose matches 5.. run scoreboard players set @s WKChoose 2

execute if score @s WKStage matches 1 if score @s WKChooseTimer matches 150.. if score @s WKChoose matches 2 if entity @p[distance=..13] run function witherking:abilities/lightning/pick
execute if score @s WKStage matches 1 if score @s WKChooseTimer matches 150.. if score @s WKChoose matches 2 unless entity @p[distance=..13] run function witherking:abilities/shadow_move1/pick

execute if score @s WKStage matches 1 if score @s WKChooseTimer matches 130.. if score @s WKChoose matches 3..4 run function witherking:abilities/wskull1/pick
# End Cycle



# Stage 2-3
execute if score @s WKStage matches 2..3 if score @s WKChooseTimer matches 1 run scoreboard players add @s WKChoose 1
# Summon Army
execute if score @s WKStage matches 2..3 if score @s WKChooseTimer matches 50.. if score @s WKChoose matches 1 run function witherking:abilities/army1/pick

# Cycle
execute if score @s WKStage matches 2..3 if score @s WKChooseTimer matches 1.. if score @s WKChoose matches 8.. run scoreboard players set @s WKChoose 2
#2
execute if score @s WKStage matches 2..3 if score @s WKChooseTimer matches 130.. if score @s WKChoose matches 2 if entity @p[distance=..15] run function witherking:abilities/lightning/pick
execute if score @s WKStage matches 2..3 if score @s WKChooseTimer matches 130.. if score @s WKChoose matches 2 unless entity @p[distance=..15] run function witherking:abilities/shadow_move2/pick
#3..4
execute if score @s WKStage matches 2..3 if score @s WKChooseTimer matches 110.. if score @s WKChoose matches 3..4 run function witherking:abilities/wskull1/pick
#5
execute if score @s WKStage matches 2..3 if score @s WKChooseTimer matches 130.. if score @s WKChoose matches 5 run function witherking:abilities/shadow_move1/pick
#6..7
execute if score @s WKStage matches 2..3 if score @s WKChooseTimer matches 110.. if score @s WKChoose matches 6..7 run function witherking:abilities/wskull1/pick
# End Cycle



# Stage 4-5
execute if score @s WKStage matches 4..5 if score @s WKChooseTimer matches 1 run scoreboard players add @s WKChoose 1
# Summon Army
execute if score @s WKStage matches 4..5 if score @s WKChooseTimer matches 50.. if score @s WKChoose matches 1 run function witherking:abilities/army1/pick

# Cycle
execute if score @s WKStage matches 4..5 if score @s WKChooseTimer matches 1.. if score @s WKChoose matches 8.. run scoreboard players set @s WKChoose 2
#2
execute if score @s WKStage matches 4..5 if score @s WKChooseTimer matches 130.. if score @s WKChoose matches 2 if entity @p[distance=..15] run function witherking:abilities/lightning/pick
execute if score @s WKStage matches 4..5 if score @s WKChooseTimer matches 130.. if score @s WKChoose matches 2 unless entity @p[distance=..15] run function witherking:abilities/shadow_move2/pick
#3..4
execute if score @s WKStage matches 4..5 if score @s WKChooseTimer matches 110.. if score @s WKChoose matches 3..4 run function witherking:abilities/wskull2/pick
#5
execute if score @s WKStage matches 4..5 if score @s WKChooseTimer matches 130.. if score @s WKChoose matches 5 run function witherking:abilities/shadow_move2/pick
#6..7
execute if score @s WKStage matches 4..5 if score @s WKChooseTimer matches 110.. if score @s WKChoose matches 6..7 run function witherking:abilities/wskull2/pick
# End Cycle
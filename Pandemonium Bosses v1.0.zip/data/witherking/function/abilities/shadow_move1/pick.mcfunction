
# Shadow move 1

# FX
execute positioned ~ ~0.5 ~ run function witherking:abilities/shadow_move1/shadow_boom_force
execute positioned ~ ~2 ~ run function witherking:abilities/shadow_move1/shadow_boom_force
execute positioned ~ ~3.5 ~ run function witherking:abilities/shadow_move1/shadow_boom_force
execute as @a[distance=..150] run playsound minecraft:entity.wither.shoot hostile @s ~ ~ ~ 1 0.5 1
execute as @a[distance=..150] run playsound minecraft:entity.wither.ambient hostile @s ~ ~ ~ 1 0.5 1



# Summon marker
execute at @p run summon marker ~ ~ ~ {Tags:["sm1_destination","init"]}

# Set ID
scoreboard players operation @n[tag=init] WKID = @s WKID
tag @e remove init



# Go Invisible
effect give @s minecraft:invisibility 12 2 true
data merge entity @s {NoAI:1,Invulnerable:1,HandItems:[{},{}],ArmorItems:[{},{},{},{}]}

# Add tag
tag @s add shadow_moving1

# Face upward
tp @s ~ ~ ~ ~ -90



# Reset timer
scoreboard players set @s WKChooseTimer -50

# Shadow move 1 sd_tick

#Timer
scoreboard players add @s WKTimerSD 1


# WK FX
particle minecraft:smoke ~ ~ ~ 0.4 0.4 0.4 0.01 40 force
particle minecraft:end_rod ~ ~ ~ 0.4 0.4 0.4 0.01 1 force



# Positioning Marker Destination
execute if score @s WKTimerSD matches ..20 at @p run tp @n[tag=sm1_destination,tag=this] ~ ~ ~

# Marker Destination FX
execute if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:end_rod ^4 ^.5 ^ 0 0 0 0.001 1 force
execute if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:soul_fire_flame ^-4 ^.5 ^ 0 0 0 0.001 1 force

execute if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s if block ~ ~-0.2 ~ #ld112:raycast_pass run tp @s ~ ~-0.2 ~
execute if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s if block ~ ~-1 ~ #ld112:raycast_pass run tp @s ~ ~-1 ~
execute if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run tp @s ~ ~ ~ ~20 ~
execute if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run tp @n[tag=sm1_destination_p,tag=this] ~ ~ ~

execute if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:firework ~ ~.3 ~10 0 0 3 0.001 1 force
execute if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:firework ~ ~.3 ~-10 0 0 3 0.001 1 force
execute if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:firework ~10 ~.3 ~ 3 0 0 0.001 1 force
execute if score @s WKTimerSD matches 20.. as @n[tag=sm1_destination,tag=this] at @s run particle minecraft:firework ~-10 ~.3 ~ 3 0 0 0.001 1 force





# Chase player
execute if score @s WKTimerSD matches 20..100 anchored feet facing entity @n[tag=sm1_destination,tag=this] feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^5 facing entity @s feet facing ^ ^ ^-1 positioned as @s run tp @s ^ ^ ^0.5 ~ ~



# End timer when catching up to destination
execute if score @s WKTimerSD matches 20..100 if entity @n[tag=sm1_destination,tag=this,distance=2.0001..4] run scoreboard players set @s WKTimerSD 101
execute if score @s WKTimerSD matches 20.. if entity @n[tag=sm1_destination,tag=this,distance=..2] run scoreboard players set @s WKTimerSD 200

# If longer than 5 seconds go directly to destination
execute if score @s WKTimerSD matches 101.. run tp @s ~ ~ ~ facing entity @n[tag=sm1_destination,tag=this]

# Advance!
tp @s ^ ^ ^1


## Impact
# Tp to destination
execute if score @s WKTimerSD matches 200 run tp @s @n[tag=sm1_destination,tag=this]
# FX
execute if score @s WKTimerSD matches 200 as @a[distance=..150] run playsound minecraft:entity.lightning_bolt.impact ambient @s ~ ~ ~ 1 1 1
execute if score @s WKTimerSD matches 200 run particle minecraft:explosion_emitter ~ ~ ~
execute if score @s WKTimerSD matches 200 rotated ~ 0 run function witherking:abilities/shadow_move1/cloud_ground_boom_strong_force
# Break surrounding blocks
execute if score @s WKTimerSD matches 200 run function witherking:misc/break_block_around_ifmobgrief
# Retrun armor and end attack
execute if score @s WKTimerSD matches 200.. run function witherking:abilities/shadow_move1/return_armor


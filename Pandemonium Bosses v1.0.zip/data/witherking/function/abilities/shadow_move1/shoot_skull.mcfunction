
# FX
execute positioned ~ ~1 ~ run function witherking:abilities/wskull1/smoke_boom_force
playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 1 0.5

## Summon the Marker
execute positioned ~ ~1 ~ rotated ~ 0 run summon marker ^1 ^ ^-1 {Tags:["WKskullToBe","WKProjectile","init"]}
execute positioned ~ ~1 ~ rotated ~ 0 run summon marker ^-1 ^ ^-1 {Tags:["WKskullToBe","WKProjectile","init"]}
execute positioned ~ ~1 ~ rotated ~ 0 run summon marker ^ ^ ^1 {Tags:["WKskullToBe","WKProjectile","init"]}

execute as @e[tag=init] at @s run tp @s ~ ~ ~ facing entity @n[tag=this,tag=WK] feet
execute as @e[tag=init] at @s run tp @s ~ ~ ~ facing ^ ^ ^-1

# Set ID
execute as @e[tag=init] run scoreboard players operation @s WKID = @n[tag=this,tag=WK] WKID

tag @e remove init

# Slowdown witherking
effect give @s minecraft:slowness 2 2 true

# Get ID
scoreboard players operation .this WKID = @s WKID
execute as @e if score @s WKID = .this WKID run tag @s add this


# TP to WK
execute if entity @n[tag=WK,tag=this,type=wither_skeleton] run tp @s @n[tag=WK,tag=this,type=wither_skeleton]

# Death detection
execute unless entity @n[tag=WK,tag=this,type=wither_skeleton] run function witherking:death/death_cutscene


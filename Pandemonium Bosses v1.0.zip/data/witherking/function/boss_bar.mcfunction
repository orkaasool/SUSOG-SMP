
## Boss Bar
# Make the Boss Bar
bossbar add witherking {"color":"#7959C2","text":"The Withered King, Blackburn"}
# Set the Boss Bar for players
execute at @e[tag=WK] run bossbar set witherking players @a
# Store the Withered King's health
execute store result bossbar witherking max run attribute @e[tag=WK,limit=1] generic.max_health get
execute store result bossbar witherking value run data get entity @e[tag=WK,limit=1] Health
# Decorations
bossbar set witherking name {"color":"#7959C2","text":"The Withered King, Blackburn"}
bossbar set witherking color purple
bossbar set witherking style progress

# Remove the Boss Bar if Withered King doesn't exist
execute unless entity @e[tag=WK] run bossbar remove witherking
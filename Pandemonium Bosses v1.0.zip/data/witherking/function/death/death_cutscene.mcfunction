## Timer
scoreboard players add @s WKDeathTimer 1

## Death Cutscene
# Particles
execute if score @s WKDeathTimer matches 1 at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 1 0.8 1
execute if score @s WKDeathTimer matches 1.. at @s run particle minecraft:smoke ~ ~ ~ 0 0.7 0 0.1 50 force
execute if score @s WKDeathTimer matches 1.. at @s run particle minecraft:end_rod ~ ~ ~ 0.7 1.4 0.7 0.01 10 force
execute if score @s WKDeathTimer matches 250.. at @s run particle minecraft:smoke ~ ~ ~ 0 0 0 0.4 30 force
execute if score @s WKDeathTimer matches 250.. at @s run particle minecraft:reverse_portal ~ ~ ~ 2 2 2 0 25 force
execute if score @s WKDeathTimer matches 400.. at @s run particle minecraft:soul_fire_flame ~ ~ ~ 4 0 4 0.1 25 force
execute if score @s WKDeathTimer matches 600.. at @s run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1
execute if score @s WKDeathTimer matches 600 at @s run playsound minecraft:entity.generic.explode master @a[distance=..32] ~ ~ ~ 10 0.4 1

# Kill stuff
execute if score @s WKDeathTimer matches 1.. run kill @e[tag=sm1_destination]

# Particle Bats
execute if score @s WKDeathTimer matches 450..600 at @s run summon bat ~ ~ ~ {Silent:1b,Invulnerable:1b,PersistenceRequired:1b,Health:999f,Motion:[0.0,0.0,0.0],Tags:["WKDeathBat"],active_effects:[{id:"minecraft:invisibility",amplifier:255,duration:-1,show_particles:0b,show_icon:0b,ambient:0b}],attributes:[{id:"minecraft:generic.max_health",base:999},{id:"minecraft:generic.burning_time",base:0}]}
execute at @e[tag=WKDeathBat] run particle minecraft:soul ~ ~ ~ 0 0 0 0 1 force

# Dialogues
execute if score @s WKDeathTimer matches 1 at @s run tellraw @a ["",{"text":"<"},{"text":"The Withered King, Blackburn","color":"#7959C2"},{"text":"> You would make a fine paladin in my army..."}]
execute if score @s WKDeathTimer matches 200 at @s run tellraw @a ["",{"text":"<"},{"text":"The Withered King, Blackburn","color":"#7959C2"},{"text":"> Our battle was indeed legendary..."}]
execute if score @s WKDeathTimer matches 400 at @s run tellraw @a ["",{"text":"<"},{"text":"The Withered King, Blackburn","color":"#7959C2"},{"text":"> I thank you..."}]
execute if score @s WKDeathTimer matches 500 at @s run tellraw @a ["",{"text":"<"},{"text":"The Withered King, Blackburn","color":"#7959C2"},{"text":"> For freeing me from this chain..."}]

# Loot and Stuff
execute if score @s WKDeathTimer matches 610 at @s run summon item ~ ~ ~ {CustomNameVisible:1b,Invulnerable:1b,CustomName:'{"bold":true,"color":"yellow","text":"Loot Chest"}',Item:{id:"minecraft:chest",count:1,components:{"minecraft:max_stack_size":1,"minecraft:item_name":'{"bold":true,"color":"yellow","italic":false,"text":"Loot Chest"}',"minecraft:container_loot":{loot_table:"witherking:wk_drop"}}}}
execute if score @s WKDeathTimer matches 610 at @s run advancement grant @a only witherking:witherking/wither_king


# Kill the funnies
execute if score @s WKDeathTimer matches 609.. run execute as @e[tag=WKDeathBat] at @s run tp @s ~ ~-5000 ~
execute if score @s WKDeathTimer matches 610.. run execute as @e[tag=WKDeathBat] at @s run kill @s
execute if score @s WKDeathTimer matches 611.. at @s run kill @s
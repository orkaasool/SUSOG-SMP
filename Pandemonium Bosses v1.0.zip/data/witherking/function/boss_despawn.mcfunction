
## When too far (despawn)
execute as @e[tag=WK] at @s if entity @p[distance=150..] run tellraw @a ["",{"text":"<"},{"text":"The Withered King, Blackburn","color":"#7959C2"},{"text":"> And you call yourself a challenger?"}]
execute as @e[tag=WK] at @s if entity @p[distance=150..] run effect give @a blindness 2 1 true
execute as @e[tag=WK] at @s if entity @p[distance=150..] run effect give @a minecraft:bad_omen 9600 4 false
execute as @e[tag=WK] at @s if entity @p[distance=150..] run title @a times 20 100 20
execute as @e[tag=WK] at @s if entity @p[distance=150..] run title @a title {"text":"Pathetic.","color":"#7959C2"}
execute as @e[tag=WK] at @s if entity @p[distance=150..] run kill @e[tag=WKDeathDetect]
execute as @e[tag=WK] at @s if entity @p[distance=150..] run tp @s ~ ~-50000 ~
execute as @e[tag=WK] at @s if entity @p[distance=150..] run function witherking:boss_killall
execute as @e[tag=WK] at @s if entity @p[distance=150..] run kill @s

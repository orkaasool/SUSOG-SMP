


particle minecraft:witch ~ ~0.5 ~ 0 0 0 1 1 force
particle minecraft:dust{color:[0.1,0.1,0.1],scale:1} ~ ~0.3 ~ 0 0 0 1 1 force

# Anim end
execute if score @s WKTimer2 matches 41 run particle minecraft:dust{color:[0.1,0.1,0.1],scale:1} ~ ~0.5 ~ 0.3 0.3 0.3 1 50 force
execute if score @s WKTimer2 matches 41 run particle minecraft:reverse_portal ~ ~0.5 ~ 0.3 0.3 0.3 1 50 force
execute if score @s WKTimer2 matches 41 run data merge entity @s {Invulnerable:0b,NoAI:0b}

execute if score @s WKTimer2 matches 41.. run data merge entity @n[tag=this_wraith,tag=WKWraithDisp] {start_interpolation:0,transformation:{scale:[1f,1f,1f]}}











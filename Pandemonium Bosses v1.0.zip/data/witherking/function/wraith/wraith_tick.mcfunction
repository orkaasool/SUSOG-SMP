
# Get ID
scoreboard players operation .this WKID = @s WKID
execute as @e if score @s WKID = .this WKID run tag @s add this

scoreboard players operation .this WKWraithID = @s WKWraithID
execute as @e if score @s WKWraithID = .this WKWraithID run tag @s add this_wraith


#Timer
scoreboard players add @s WKTimer1 1
scoreboard players add @s WKTimer2 1


# Aim
execute if score @s WKTimer1 matches 120 if entity @p[distance=5..30] facing entity @p feet run function witherking:wraith/aim
# Shoot FX
execute if score @s WKTimer1 matches 120 if entity @p[distance=5..30] rotated ~ ~90 run function witherking:abilities/wskull1/smoke_boom_force
# Shoot
execute if score @s WKTimer1 matches 120 if entity @p[distance=5..30] positioned ~ ~0.5 ~ facing entity @p feet positioned ^ ^ ^1.5 if block ~ ~ ~ #ld112:raycast_pass run function witherking:wraith/shoot with storage minecraft:aim
# Reset Timer
execute if score @s WKTimer1 matches 120.. if entity @p[distance=5..30] run scoreboard players set @s WKTimer1 0



# Hurt SFX
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:entity.wither_skeleton.hurt hostile @a ~ ~ ~ 1 1
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:entity.wither.hurt hostile @a ~ ~ ~ 1 0.8



# FX
execute if score @s WKTimer2 matches 42.. run particle minecraft:dust{color:[0.1,0.1,0.1],scale:1} ~ ~ ~ 0.3 0.3 0.3 0.1 5 force


# Disp
execute as @n[tag=this_wraith,tag=WKWraithDisp,type=item_display] at @s facing entity @p eyes run tp @s ~ ~ ~ ~ ~


execute if entity @p[distance=30..] facing entity @p eyes run tp @s ^ ^ ^1 ~ ~


# Spawn animation
execute unless score @s WKTimer2 matches 42.. run function witherking:wraith/spawn_anim





# Remove this and this_wraith tag
tag @e remove this
tag @e remove this_wraith







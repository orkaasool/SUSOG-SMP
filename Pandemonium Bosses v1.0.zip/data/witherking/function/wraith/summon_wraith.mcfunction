



summon vex ~ ~ ~ {Invulnerable:1b,NoAI:1b,Silent:1b,Health:20f,Tags:["WKShielder","WKWraith","init","WKArmy2"],HandItems:[{},{}],Passengers:[{id:"minecraft:item_display",Tags:["WKWraithDisp","init"],teleport_duration:3,interpolation_duration:13,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-1f,0f],scale:[0.1f,0.1f,0.1f]},item:{id:"minecraft:white_dye",count:1,components:{"minecraft:custom_model_data":910}}}],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}],attributes:[{id:"minecraft:generic.max_health",base:20},{id:"minecraft:generic.scale",base:2}]}


# Give Wraith ID
scoreboard players add .cur_id WKWraithID 1
scoreboard players operation @e[tag=init] WKWraithID = .cur_id WKWraithID

# Give WK ID when summoner has ID
execute if score @s WKID matches 1.. run scoreboard players operation @e[tag=init] WKID = @s WKID


# Set team
team join witherking_andfriends @e[tag=init]



# Make them angry at player
damage @n[type=vex,tag=init] 0.01 minecraft:player_attack by @p

# Randomize a delay to their wither skull attack
execute store result score @n[type=vex,tag=init] WKTimer1 run random value -40..0



# Remove init tag
tag @e remove init


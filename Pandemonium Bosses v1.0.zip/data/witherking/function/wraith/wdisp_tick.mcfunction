

# Get ID
scoreboard players operation .this WKWraithID = @s WKWraithID
execute as @e if score @s WKWraithID = .this WKWraithID run tag @s add this

# Death
execute unless entity @n[tag=this,tag=WKWraith] run particle minecraft:dust{color:[0.1,0.1,0.1],scale:1} ~ ~-0.5 ~ 0.3 0.3 0.3 1 50 force
execute unless entity @n[tag=this,tag=WKWraith] run particle minecraft:reverse_portal ~ ~-0.5 ~ 0.3 0.3 0.3 1 50 force
execute unless entity @n[tag=this,tag=WKWraith] run playsound minecraft:entity.vex.death hostile @a ~ ~ ~ 1 0.5
execute unless entity @n[tag=this,tag=WKWraith] run playsound minecraft:entity.wither_skeleton.death hostile @a ~ ~ ~ 1 1
execute unless entity @n[tag=this,tag=WKWraith] run kill @s


# Remove this tag
tag @e remove this
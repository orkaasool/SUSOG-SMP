
#$say $(text)


$summon wither_skull ~ ~ ~ {Tags:["WKWitherSkull","init"],acceleration_power:0.1d,dangerous:0b,Motion:$(Motion)}

# Shoot sound
playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 1 1

# Set owner
data modify entity @n[tag=init] Owner set from entity @s UUID
tag @e remove init


# Destroy altar
setblock ~ ~ ~ air destroy
setblock ~ ~-1 ~ air destroy
setblock ~ ~-2 ~ air destroy
setblock ~1 ~-1 ~ air destroy
setblock ~-1 ~-1 ~ air destroy
setblock ~ ~-1 ~1 air destroy
setblock ~ ~-1 ~-1 air destroy
setblock ~1 ~-2 ~ air destroy
setblock ~-1 ~-2 ~ air destroy
setblock ~ ~-2 ~1 air destroy
setblock ~ ~-2 ~-1 air destroy
setblock ~1 ~-2 ~1 air destroy
setblock ~-1 ~-2 ~-1 air destroy
setblock ~-1 ~-2 ~1 air destroy
setblock ~1 ~-2 ~-1 air destroy
particle smoke ~ ~ ~ 1 1 1 0.5 100 force
summon minecraft:lightning_bolt

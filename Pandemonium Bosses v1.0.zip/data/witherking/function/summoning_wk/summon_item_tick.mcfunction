
## Timer
scoreboard players add @s WKSummonTimer 1


execute if score @s WKSummonTimer matches ..39 run execute align xyz positioned ~0.5 ~ ~0.5 run tp @s ~ ~ ~

execute if score @s WKSummonTimer matches 40 run data merge entity @s {Age:-32768,Health:32767,PickupDelay:32767,Item:{id:"minecraft:nether_star",count:1,components:{"minecraft:fire_resistant":{}}}}

## Destroy Altar
execute if score @s WKSummonTimer matches 40 run function witherking:summoning_wk/destroy_altar

## Grant Advancement & Play Wither Sound
execute if score @s WKSummonTimer matches 40 run advancement grant @a only witherking:witherking/root
execute if score @s WKSummonTimer matches 40 run playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 5 1 0

## Particle Armor Stand
execute if score @s WKSummonTimer matches 55 run summon armor_stand ~ ~ ~ {Marker:1b,HasVisualFire:0b,Silent:1b,Invulnerable:1b,Invisible:1b,Tags:["WKSummonParticle"]}
execute as @e[tag=WKSummonParticle] run tp @s ~ ~ ~ ~7 ~

## Alchemy Circle 1
execute if score @s WKSummonTimer matches 55 run summon armor_stand ~ ~ ~ {Marker:1b,HasVisualFire:0b,Silent:1b,Invulnerable:1b,Invisible:1b,Tags:["WKSummonCircle"]}
execute as @e[tag=WKSummonCircle] run tp @s ~ ~ ~ ~.2 ~
execute as @e[tag=WKSummonCircle] positioned ~ ~0.5 ~ run function witherking:boss_summon_circle

## Circular Particles
execute run particle minecraft:end_rod ~ ~ ~ 0.1 0.1 0.1 0.1 5 force
execute as @e[tag=WKSummonParticle] run particle minecraft:end_rod ^ ^ ^4 0 0 0 0.01 5 force
execute as @e[tag=WKSummonParticle] run particle minecraft:end_rod ^ ^ ^-4 0 0 0 0.01 5 force
execute if score @s WKSummonTimer matches 90.. at @e[tag=WKSummonParticle] run particle minecraft:soul ^ ^0.5 ^6 0 0 0 0 1 force
execute if score @s WKSummonTimer matches 90.. at @e[tag=WKSummonParticle] run particle minecraft:soul ^ ^0.5 ^-6 0 0 0 0 1 force
execute if score @s WKSummonTimer matches 90.. at @e[tag=WKSummonParticle] run particle minecraft:soul ^6 ^0.5 ^ 0 0 0 0 1 force
execute if score @s WKSummonTimer matches 90.. at @e[tag=WKSummonParticle] run particle minecraft:soul ^-6 ^0.5 ^ 0 0 0 0 1 force

## Smaller Particles
execute if score @s WKSummonTimer matches 90..120 at @e[tag=WKSummonParticle] run summon bat ~ ~ ~ {HasVisualFire:0b,Silent:1b,Invulnerable:1b,Tags:["WKSummonParticleSmall"],active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b,show_icon:0b,ambient:0b}]}
execute if score @s WKSummonTimer matches 130 at @e[tag=WKSummonParticleSmall] run particle minecraft:soul_fire_flame ~ ~ ~ 0 2 0 0 10 force
execute if score @s WKSummonTimer matches 130 at @e[tag=WKSummonParticleSmall] run particle minecraft:soul_fire_flame ~ ~ ~ 0 2 0 0 10 force
execute if score @s WKSummonTimer matches 140 at @e[tag=WKSummonParticleSmall] run particle minecraft:soul_fire_flame ~ ~ ~ 0 2 0 0 10 force
execute if score @s WKSummonTimer matches 150 at @e[tag=WKSummonParticleSmall] run particle minecraft:soul_fire_flame ~ ~ ~ 0 2 0 0 10 force
execute if score @s WKSummonTimer matches 160 at @e[tag=WKSummonParticleSmall] run particle minecraft:soul_fire_flame ~ ~ ~ 0 2 0 0 10 force
execute if score @s WKSummonTimer matches 170 at @e[tag=WKSummonParticleSmall] run particle minecraft:soul_fire_flame ~ ~ ~ 0 2 0 0 10 force
execute if score @s WKSummonTimer matches 180 at @e[tag=WKSummonParticleSmall] run particle minecraft:soul_fire_flame ~ ~ ~ 0 2 0 0 10 force
execute if score @s WKSummonTimer matches 190 at @e[tag=WKSummonParticleSmall] run particle minecraft:soul_fire_flame ~ ~ ~ 0 2 0 0 10 force
execute if score @s WKSummonTimer matches 130..190 at @e[tag=WKSummonParticleSmall] run particle minecraft:portal ~ ~ ~ 0 0 0 0 1 force
# Kill the smaller particles
execute if score @s WKSummonTimer matches 191 as @e[tag=WKSummonParticleSmall] run tp @s ~ ~-50000 ~
execute if score @s WKSummonTimer matches 192 as @e[tag=WKSummonParticleSmall] run kill @s

## Lightning Bolts
execute if score @s WKSummonTimer matches 200..249 run execute as @e[tag=WKSummonParticle] run tp @s ~ ~.3 ~
execute if score @s WKSummonTimer matches 200 run summon minecraft:lightning_bolt
execute if score @s WKSummonTimer matches 204 run summon minecraft:lightning_bolt
execute if score @s WKSummonTimer matches 207 run summon minecraft:lightning_bolt
execute if score @s WKSummonTimer matches 209 run summon minecraft:lightning_bolt
execute if score @s WKSummonTimer matches 210..249 run summon minecraft:lightning_bolt

## Summonning
# Kill the Particle Armor Stands
execute if score @s WKSummonTimer matches 250 run kill @e[tag=WKSummonParticle]
execute if score @s WKSummonTimer matches 250 run kill @e[tag=WKSummonCircle]
# Debuff the players
execute if score @s WKSummonTimer matches 250 run effect give @a[distance=..150] blindness 2 1 true
# Titles "You dare challenge me?"
execute if score @s WKSummonTimer matches 250 run title @a times 20 100 20
execute if score @s WKSummonTimer matches 250 run title @a title {"text":"You dare challenge me?","color":"#7959C2"}
# Summon The Withered King
execute if score @s WKSummonTimer matches 250 run function witherking:summoning_wk/true_summon

# Kill the Nether Star
execute if score @s WKSummonTimer matches 250.. run kill @s
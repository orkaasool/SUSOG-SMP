
tellraw @a ["",{"text":"=================================","bold":true},{"text":"\n \u0020 \u0020 \u0020 \u0020 \u0020"},{"text":"Pandemonium Bosses","bold":true,"color":"gold"},{"text":"\n \u0020 \u0020 \u0020 \u0020 \u0020 \u0020 \u0020 \u0020 \u0020v0.1\n \u0020 \u0020 \u0020 \u0020 \u0020"},{"text":"By: Nosaka and Eggy112","color":"blue"},{"text":"\n"},{"text":"=================================","bold":true}]

# --------------------------------------------------------
# ---------------------- Objectives ----------------------
# --------------------------------------------------------
## ID
scoreboard objectives add WKID dummy

## Death Detection Timer
scoreboard objectives add WKDeathTimer dummy
## Withered King's Health
scoreboard objectives add WKHealth dummy
## Initial Summon Timer
scoreboard objectives add WKSummonTimer dummy

## Boss Roulette Timer
scoreboard objectives add WKStage dummy
scoreboard objectives add WKChoose dummy
scoreboard objectives add WKChoose2 dummy
scoreboard objectives add WKChooseTimer dummy

## General Scoreboards
scoreboard objectives add WKTimer1 dummy
scoreboard objectives add WKTimer2 dummy
scoreboard objectives add WKVar1 dummy

## Lightning Ability Timer
scoreboard objectives add WKLightningTimer dummy
scoreboard objectives add WKLightningBatTimer dummy
scoreboard objectives add WKLightningAreaTimer dummy

## Wither Skull 1 Ability
data merge storage minecraft:aim {Motion:[0.0d,0.0d,0.0d]}

## Shadow Move Ability
scoreboard objectives add WKTimerSD dummy
scoreboard objectives add WKSDStage dummy

## Summon Army 1 Ability
scoreboard objectives add WKWraithID dummy
scoreboard objectives add WKTimerA dummy
scoreboard objectives add WKTimerAFX dummy
team add witherking_andfriends
team modify witherking_andfriends friendlyFire false
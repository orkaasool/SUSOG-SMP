

execute store result score .mobgrief WKVar1 run gamerule mobGriefing
execute if score .mobgrief WKVar1 matches 1 run function witherking:misc/break_block_around


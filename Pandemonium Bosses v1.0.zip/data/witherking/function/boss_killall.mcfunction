
## Kill Everything Related to the Boss but not the Boss
kill @e[tag=WKRainfallBat]
kill @e[tag=WKRainfallThing]
kill @e[tag=WKMinion1]
kill @e[tag=WKWings]

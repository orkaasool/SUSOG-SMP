
# Get ID
scoreboard players operation .this WKID = @s WKID
execute as @e if score @s WKID = .this WKID run tag @s add this


## Boss Particles
particle minecraft:reverse_portal ~ ~ ~ 7 0.5 7 0 5 force
particle minecraft:soul ~ ~ ~ 7 0.5 7 0 3 force
execute unless block ~ ~-1 ~ air run particle minecraft:smoke ~ ~ ~ 0.3 0 0.3 0 5 force
execute unless block ~ ~-1 ~ air run particle minecraft:end_rod ~ ~-0.5 ~ 0.3 0 0.3 0.1 2 force


## Store Boss Health
execute store result score @s WKHealth run data get entity @s Health


# Handle stages
function witherking:boss_stages


# Choose ability
function witherking:abilities/choose_ability

# FOR TEST vvvv
#scoreboard players set @n[tag=WK] WKStage 4
#function witherking:abilities/choose_ability_test



## When too far (despawn)
execute if entity @p[distance=150..] run tellraw @a ["",{"text":"<"},{"text":"The Withered King, Blackburn","color":"#7959C2"},{"text":"> And you call yourself a challenger?"}]
execute if entity @p[distance=150..] run effect give @a blindness 2 1 true
execute if entity @p[distance=150..] run effect give @a minecraft:bad_omen 9600 4 false
execute if entity @p[distance=150..] run title @a times 20 100 20
execute if entity @p[distance=150..] run title @a title {"text":"Pathetic.","color":"#7959C2"}
execute if entity @p[distance=150..] run kill @e[tag=WKDeathDetect,tag=this]
execute if entity @p[distance=150..] run tp @s ~ ~-50000 ~
execute if entity @p[distance=150..] run function witherking:boss_killall
execute if entity @p[distance=150..] run kill @s


# Abilities
execute if entity @s[tag=shadow_moving1] run function witherking:abilities/shadow_move1/sd_tick
execute if entity @s[tag=shadow_moving2] run function witherking:abilities/shadow_move2/sd_tick
execute if entity @s[tag=summon_army1] run function witherking:abilities/army1/main_tick
execute if entity @s[tag=summon_army2] run function witherking:abilities/army2/main_tick
execute if entity @s[tag=wskulling2] run function witherking:abilities/wskull2/main_tick




# Remove this tag
tag @e remove this

## Boss Wings
# execute if entity @e[tag=WK] run execute unless entity @e[tag=WKWings] run summon armor_stand ~ ~ ~ {Marker:1b,HasVisualFire:0b,Silent:1b,Invulnerable:1b,Invisible:1b,Tags:["WKWings"]}
# execute as @e[tag=WKWings] run execute unless entity @e[tag=WK] run kill @s
# execute as @e[tag=WKWings] at @s run tp @s @e[tag=WK,limit=1,sort=nearest]
# execute as @e[tag=WKWings] at @s run tp @s ^ ^ ^-0.8 ~ 0
# execute as @e[tag=WKWings] at @s positioned ~ ~1 ~ run function witherking:boss_wings
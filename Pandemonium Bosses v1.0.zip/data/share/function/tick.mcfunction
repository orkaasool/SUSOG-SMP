
## Boss Theme
# Timer
execute as @e[tag=Boss,limit=1] run scoreboard players add .BossTheme BossThemeTimer 1
execute unless entity @e[tag=Boss] run scoreboard players reset .BossTheme BossThemeTimer
execute as @e[tag=Boss,limit=1] if score .BossTheme BossThemeTimer matches 2460.. run scoreboard players reset .BossTheme BossThemeTimer
# Playsound
execute as @e[tag=Boss] if score .BossTheme BossThemeTimer matches 1 at @s run playsound minecraft:boss.theme master @a ~ ~ ~ 1 1 1
# Stopsound
execute unless entity @e[tag=Boss] run stopsound @a master minecraft:boss.theme

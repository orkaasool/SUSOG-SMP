tellraw @a ["",{"text":"A collab datapack!","color":"blue"}]

scoreboard objectives add BossThemeTimer dummy